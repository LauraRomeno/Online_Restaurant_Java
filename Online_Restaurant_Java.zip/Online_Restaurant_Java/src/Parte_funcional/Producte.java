/** 
 * Clase producto (abstracta)
 * 
 * @author German Telmo Eizaguirre Suarez
 * 
 */

package Parte_funcional;

import java.text.DecimalFormat;


public abstract class Producte {
	
	/*Variables*/
	private String nombre;
	private double precio;
	private int descuento;
	private int codigo;
	private static int ultimo_codigo = 0;
	private final String tipus="P";
	
	/**
	 * Constructor para la clase producto.
	 * @param new_nombre nombre del producto
	 * @param new_precio precio del producto sin aplicar descuento (en euros)
	 * @param new_descuento descuento del producto (sobre sobre 100 como precio total del producto)
	 */
	public Producte (String new_nombre, double new_precio, int new_descuento){
		nombre=new_nombre;
		precio=new_precio;
		if ((new_descuento<0)||(new_descuento>100)) descuento=0;
		else descuento =new_descuento;
		codigo= ++ultimo_codigo;
	}
	
	/**
	 * Setter para el nombre del producto.
	 * @param nombre nuevo nom bre del producto
	 */
	public void setNombre (String nombre){
		this.nombre=nombre;
	}
	
	/**
	 * Setter para el precio del producto.
	 * @param precio nuevo precio del producto
	 */
	public void setPrecio (double precio){
		this.precio=precio;
	}
	
	/**
	 * Setter para el descuento del producto.
	 * @param new_descuento nuevo descuento del producto
	 */
	public void setDescuento (int new_descuento){
		if ((new_descuento>0)&&(new_descuento<100))descuento=new_descuento;
	}
	
	/**
	 * Getter para el nombre del producto.
	 * @return nombre actual del producto
	 */
	public String getNombre (){
		return nombre;
	}
	
	/**
	 * Getter para el precio del producto.
	 * @return precio actual (sin descuento) del producto
	 */
	public double getPrecio (){
		return precio;
	}
	
	/**
	 * Getter para el descuento del producto (sobre 100)
	 * @return descuento del producto sobre 100
	 */
	public int getDescuento (){
		return descuento;
	}
	
	/**
	 * M�todo para obtener el valor del precio con el descuento aplicado.
	 * @return precio con el porcentaje apropiado del descuento restado.
	 */
	public double getPrecioConDescuento (){
		
		double precioDescuento= precio*descuento/100;
		return precioDescuento;
	}
	
	/**
	 * Getter para el codigo del producto.
	 * @return codigo identificador del producto
	 */
	public int getCodigo(){
		return codigo;
	}
	
	/**
	 * M�todo para obtener el tipo de producto (P de producto).
	 * Se implement� a petici�n del programador de la lectura de
	 * producto desde fichero de texto.
	 * @return "P" de producto
	 */
	public String getTipus (){
		return tipus;
	}
	
	/**
	 * Getter para el est�tico del �ltimo c�digo de producto asignado
	 * @return �ltimo c�digo de producto asignado por el programa
	 */
	public static int getUltimo_codigo(){
		return ultimo_codigo;
	}
	
	/**
	 * M�todo toString que devuelve una String con la informaci�n del producto.
	 */
	public String toString (){
		DecimalFormat df = new DecimalFormat("0.00##");/*Clase para dar formato de dos decimales*/
		return (" "+nombre+", c�digo de producto: "+codigo+"\n Precio: "+df.format(precio)+"� con descuento posible del "+descuento+"%");
	}
	

}
