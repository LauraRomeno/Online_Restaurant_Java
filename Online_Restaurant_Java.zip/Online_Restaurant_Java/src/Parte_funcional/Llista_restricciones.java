/** 
 * Clase lista de restricciones 
 * 
 * @author German Telmo Eizaguirre Suarez
 * 
 */

package Parte_funcional;

public class Llista_restricciones {

	/*Variables*/
	String[] lista;
	private int numero_restricciones;
	
	/**
	 * Constructor para la lista de restricciones.
	 * @param tama�o_lista cantidad m�xima de restricciones que se pueden almacenar
	 */
	public Llista_restricciones (int tama�o_lista){
		lista=new String[tama�o_lista];
		numero_restricciones=0;
	}
	
	/**
	 * Getter para el n�mero de restricciones almacenadas actualmente en la lista.
	 * @return la cantidad de restricciones que almacena la lista.
	 */
	public int getSize(){
		return numero_restricciones;
	}
	
	/**
	 * M�todo para a�adir una restricci�n a la lista de restricciones.
	 * @param nueva_restriccion String con la restricci�n a a�adir
	 */
	public void a�adir_restriccion (String nueva_restriccion){
		if (numero_restricciones<lista.length) lista[numero_restricciones]=nueva_restriccion;
		numero_restricciones++;
	}
	
	/**
	 * M�todo para eliminar una restricci�n recibida por par�metro.
	 * @param fuera_restriccion String de la restricci�n a eliminar
	 * @return true si la restricci�n ha sido encontrada y eliminada - false si no exist�a la restricci�n
	 */
	public boolean eliminar_restriccion (String fuera_restriccion){
		
		int counter=0;
		boolean encontrado=false;
		while ((counter<numero_restricciones)&&(encontrado==false)){
				if (lista[counter].equals(fuera_restriccion)){
					encontrado=true;
					
					for(int i=counter; i<numero_restricciones-1; i++){
						lista[i]=lista[i+1];
					}
				}
				else counter++;
		}
		return encontrado;
	}
	
	/**
	 * M�todo para obtener una restricci�n a partir de su posici�n en la lista.
	 * @param posicion posici�n de la restricci�n
	 * @return String de la posici�n deseada - null si la posici�n no es correcta
	 */
	public String getRestriccion (int posicion){
		
		if (posicion<numero_restricciones) return lista[posicion];
		else return null;
	}
	
	/**
	 * M�todo para copiar los datos de la lista a una nueva instancia.
	 * @return Instancia de una nueva lista de restricciones con los mismos datos que la original
	 */
	public Llista_restricciones copy(){
		Llista_restricciones listaDevolver =new Llista_restricciones(lista.length);
		for (int i=0; i<numero_restricciones; i++){
			listaDevolver.a�adir_restriccion(lista[i]);
		}
		return listaDevolver;
	}
	
	/**
	 * M�todo toSTring de la lista de restricciones.
	 */
	public String toString (){
		String devolver_restricciones=" ";
		for (int i=0; i<numero_restricciones; i++){
			devolver_restricciones+= lista[i];
			if (i!=numero_restricciones-1){
				devolver_restricciones+= ", ";
			}
		}
		return (devolver_restricciones);
	}
}
