package Parte_funcional;

/**
 * Classe client : cont� les dades d'un client
 * Cont� m�todes per poder afegir noves comandes a la seva llista de comandes
 */
public class Client {

	private String nom, adre�a, telefon, nomUsuari, contrasenya;
	private int idClient, numComandes = 0;
	private boolean preferencia = false;
	private Comanda[] lista_comandas = new Comanda[100]; // Suposem Max comandes 100
															
	private Llista_restricciones lista_restricciones = new Llista_restricciones(10);// Suposem Max restricions 10
	private static int id_ultimo = 0;

	/**
	 * Contructor de la classe Client
	 * 
	 * @param nom
	 *            nom del cilent
	 * @param adre�a
	 *            direcci� del client
	 * @param telefon
	 *           telefon del client
	 * @param nomUsuari
	 *            nom d'usuari
	 * @param contrasenya
	 *            contrasenya
	 * @param lista
	 *            llista de restricions aliment�ries
	 */
	public Client(String nom, String adre�a, String telefon, String nomUsuari, String contrasenya,
			Llista_restricciones lista) {
		this.nom = nom;
		this.adre�a = adre�a;
		this.telefon = telefon;
		this.nomUsuari = nomUsuari;
		this.contrasenya = contrasenya;
		this.lista_restricciones = lista;
		idClient = id_ultimo++; // Guardem un id i agumentem el numero

	}

	/**
	 * Getter per al nom del cilent
	 * 
	 * @return the nom
	 */
	public String getNom() {
		return nom;
	}

	/**
	 * Setter per al nom del cilent
	 * 
	 * @param nom
	 *            the nom to set
	 */
	public void setNom(String nom) {
		this.nom = nom;
	}

	/**
	 * Getter per la direcci� del client
	 * 
	 * @return the adre�a
	 */
	public String getAdre�a() {
		return adre�a;
	}

	/**
	 * Setter per la direcci� del client
	 * 
	 * @param adre�a
	 *            the adre�a to set
	 */
	public void setAdre�a(String adre�a) {
		this.adre�a = adre�a;
	}

	/**
	 * Getter per al telefon del client
	 * 
	 * @return the telefon
	 */
	public String getTelefon() {
		return telefon;
	}

	/**
	 * Setter per al telefon del client
	 * 
	 * @param telefon
	 *            the telefon to set
	 */
	public void setTelefon(String telefon) {
		this.telefon = telefon;
	}

	/**
	 * Getter per al nom d'usuari del client
	 * 
	 * @return the nomUsuari
	 */
	public String getNomUsuari() {
		return nomUsuari;
	}

	/**
	 * Setter per al nom d'usuari del client
	 * 
	 * @param nomUsuari
	 *            the nomUsuari to set
	 */
	public void setNomUsuari(String nomUsuari) {
		this.nomUsuari = nomUsuari;
	}

	/**
	 * Getter per a la contrasenya del client
	 * 
	 * @return the contrasenya
	 */
	public String getContrasenya() {
		return contrasenya;
	}

	/**
	 * Setter per a la contrasenya del client
	 * 
	 * @param contrasenya
	 *            the contrasenya to set
	 */
	public void setContrasenya(String contrasenya) {
		this.contrasenya = contrasenya;
	}

	/**
	 * Getter per a l'ID del client
	 * 
	 * @return the idClient
	 */
	public int getIdClient() {
		return idClient;
	}

	/**
	 * Setter per a l'ID del client
	 * 
	 * @param idClient
	 *            the idClient to set
	 */
	public void setIdClient(int idClient) {
		this.idClient = idClient;
	}

	/**
	 * Getter per la prefencia del client
	 * 
	 * @return the preferencia
	 */
	public boolean getPreferencia() {
		return preferencia;
	}

	/**
	 * Setter per la prefencia del client
	 * 
	 * @param preferencia
	 *            the preferencia to set
	 */
	public void setPreferencia(boolean preferencia) {
		this.preferencia = preferencia;
	}

	/**
	 * Getter per a la llista de comandes
	 * 
	 * @return the lista_comandas
	 */
	public Comanda[] getLista_comandas() {
		return lista_comandas;
	}

	/**
	 * Setter per a la llista de comandes
	 * 
	 * @param lista_comandas
	 *            the lista_comandas to set
	 */
	public void setLista_comandas(Comanda[] lista_comandas) {
		this.lista_comandas = lista_comandas;
	}

	/**
	 * Getter per al nombre de comandes totals del client
	 * 
	 * @return the numComandes
	 */
	public int getNumComandes() {
		return numComandes;
	}

	/**
	 * Setter per al nombre de comandes totals del client
	 * 
	 * @param numComandes
	 *            the numComandes to set
	 */
	public void setNumComandes(int numComandes) {
		this.numComandes = numComandes;
	}

	/**
	 * Getter per a la llista de restriccions del client
	 * 
	 * @return the lista_restricciones
	 */
	public Llista_restricciones getLista_restricciones() {
		return lista_restricciones;
	}

	/**
	 * Setter per a la llista de restriccions del client
	 * 
	 * @param lista_restricciones
	 *            the lista_restricciones to set
	 */
	public void setLista_restricciones(Llista_restricciones lista_restricciones) {
		this.lista_restricciones = lista_restricciones;
	}

	/**
	 * Getter per a l'�ltim id de la classe client
	 * 
	 * @return the id_ultimo
	 */
	public static int getId_ultimo() {
		return id_ultimo;
	}

	/**
	 * Setter per a l'�ltim id de la classe client
	 * 
	 * @param id_ultimo
	 *            the id_ultimo to set
	 */
	public static void setId_ultimo(int id_ultimo) {
		Client.id_ultimo = id_ultimo;
	}

	
	/**
	 * M�tode que copia una comanda anterior i l'afegeix a la llista de comandes
	 * 
	 * @param comanda
	 *            : comanda anterior que es vol copiar
	 */
	public void copiarComanda(Comanda comanda) {
		
		Comanda nova_comanda = new Comanda(idClient);
		nova_comanda = comanda; // Es pot assignar per @ ja que no s'ha de modificar
		afegirComanda(nova_comanda);

	}

/**
 * M�tode per afegir una nova comanda a la llista de comandes
 * @param comanda : comanda a afegir
 */

	public void afegirComanda(Comanda comanda){
	
		try{		
		lista_comandas[numComandes]= comanda;
		numComandes++;
		}
		
		catch (ArrayIndexOutOfBoundsException e){ } //Si est� plena la taula no afegir comanda
			
		if (numComandes==5)	preferencia=true;  //Preferent a partir de 5 comandes
		
	
		
	}

	/**
	 * M�tode que crea un string amb les caracter�siques de cada comanda per
	 * obtenir un historial de comandes
	 * 
	 * @return string d'historial de comandes
	 */
	public String llistarComandas() {

		String llista="";

		for (int i=numComandes-1; i >=0; i--) {

			llista = (llista + "\n" + lista_comandas[i].toString());
		}

		return llista;
	}

	



	/** M�todo to string  que muestra el contenido de las variables del cliente
	 * @return String con todos los datos del cliente
	 **/
	@Override
	public String toString() {
		return "Client [nom=" + nom + ", adre�a=" + adre�a + ", telefon=" + telefon + ", nomUsuari=" + nomUsuari
				+ ", contrasenya=" + contrasenya + ", idClient=" + idClient + ", numComandes=" + numComandes
				+ ", preferencia=" + preferencia + ", lista_restricciones=" + lista_restricciones + "]";
	}


	}

