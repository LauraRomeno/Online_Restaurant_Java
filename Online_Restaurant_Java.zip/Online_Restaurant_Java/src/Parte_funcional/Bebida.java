/** 
 * Clase bebida
 * 
 * @author German Telmo Eizaguirre Suarez
 * 
 */
package Parte_funcional;

public class Bebida extends Producte {
	
	/*Variables*/
	int volumen;
	Boolean alcohol;
	private final String tipus="B";
	
	/**
	 * Constructor para la clase bebida.
	 * @param new_nombre nombre de la bebida
	 * @param new_precio precio de la bebida (en euros)
	 * @param new_descuento posible descuento de la bebida (sobre 100)
	 * @param new_volumen volumen de la bebida (en mL)
	 * @param alcohol booleano que determina si tiene o no tiene alcohol
	 */
	public Bebida (String new_nombre, double new_precio, int new_descuento, int new_volumen, Boolean alcohol){
		
		super(new_nombre, new_precio, new_descuento);
		volumen=new_volumen;
		this.alcohol= alcohol;
	}
	
	/**
	 * Getter para el voloumen de la bebida
	 * @return volumen de la bebida en mL
	 */
	public int getVolumen (){
		return volumen;
	}
	
	/**
	 * Geter para el contenido en alcohol de la bebida
	 * @return true: tiene alcohol - false: no tiene alcohol
	 */
	public Boolean getAlcohol (){
		return alcohol;
	}
	
	/**
	 * Setter para el volumen de la bebida
	 * @param new_volumen  nuevo volumen de la bebida (mL)
	 */
	public void setVolumen (int new_volumen){
		volumen=new_volumen;
	}
	
	/**
	 * M�todo para obtener el tipo de producto (B de bebida).
	 * @return "B" de bebida
	 *  getTipus de Producto
	 */
	@Override
	public String getTipus (){
		return tipus;
	}
	
	
	/**
	 *  toString para la clase bebida, devuelve String de las variables de la superclase producte y las variables volumen y alcohol.
	 */
	public String toString (){
		return (super.toString()+"\n Volumen:"+volumen+" mL, alcohol "+alcohol+".");
	}
}