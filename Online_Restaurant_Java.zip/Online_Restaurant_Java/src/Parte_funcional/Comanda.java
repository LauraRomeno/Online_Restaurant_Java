package Parte_funcional;

import java.util.Date;
import java.text.DateFormat;
import java.text.SimpleDateFormat;

public class Comanda {

	DateFormat df= new SimpleDateFormat("HH:MM:SS");
	private int numelem = 0;
	private Producte[] lista_productos;
	private int[] lista_cantidades;
	Date hora;
	private float preuFinal;
	private int ID_cliente;
	private int ID_comanda;
	private static int ultimo_ID = 0;

	/**
	 * Getter that returns the number of elements in the order
	 * 
	 * @return the numelem
	 */
	public int getNumelem() {
		return numelem;
	}

	/**
	 * @param numelem
	 *            the numelem to set
	 */
	public void setNumelem(int numelem) {
		this.numelem = numelem;
	}

	/**
	 * Getter that returns the list of products
	 * 
	 * @return the lista_productos
	 */
	public Producte[] getLista_productos() {
		return lista_productos;
	}

	/**
	 * @param lista_productos
	 *            the lista_productos to set
	 */
	public void setLista_productos(Producte[] lista_productos) {
		this.lista_productos = lista_productos;
	}

	/**
	 * Getter that returns the list of quantities
	 * 
	 * @return the lista_cantidades
	 */
	public int[] getLista_cantidades() {
		return lista_cantidades;
	}

	/**
	 * @param lista_cantidades
	 *            the lista_cantidades to set
	 */
	public void setLista_cantidades(int[] lista_cantidades) {
		this.lista_cantidades = lista_cantidades;
	}

	/**
	 * Getter that returns the date
	 * 
	 * @return The date
	 */
	public Date getHora() {
		return hora;
	}

	/**
	 * @param hora
	 *            the hora to set
	 */
	public void setHora(Date hora) {
		this.hora = hora;
	}

	/**
	 * Getter that returns the final price
	 * 
	 * @return the preuFinal
	 */
	public float getPreuFinal() {
		return preuFinal;
	}

	/**
	 * @param preuFinal
	 *            the preuFinal to set
	 */
	public void setPreuFinal(float preuFinal) {
		this.preuFinal = preuFinal;
	}

	/**
	 * Getter that returns the ID of the client
	 * 
	 * @return the iD_cliente
	 */
	public int getID_cliente() {
		return ID_cliente;
	}

	/**
	 * @param iD_cliente
	 *            the iD_cliente to set
	 */
	public void setID_cliente(int iD_cliente) {
		ID_cliente = iD_cliente;
	}

	/**
	 * Getter that returns the ID of the order
	 * 
	 * @return the iD_comanda
	 */
	public int getID_comanda() {
		return ID_comanda;
	}

	/**
	 * @param iD_comanda
	 *            the iD_comanda to set
	 */
	public void setID_comanda(int iD_comanda) {
		ID_comanda = iD_comanda;
	}

	/**
	 * Getter that returns the last ID that we have set in an order
	 * 
	 * @return the ultimo_ID
	 */
	public static int getUltimo_ID() {
		return ultimo_ID;
	}

	/**
	 * @param ultimo_ID
	 *            the ultimo_ID to set
	 */
	public static void setUltimo_ID(int ultimo_ID) {
		Comanda.ultimo_ID = ultimo_ID;
	}

	/**
	 * Constructor of the class
	 * 
	 * @param id_cliente codi per identificar al client
	 */

	public Comanda(int id_cliente) {
		lista_productos = new Producte[100];
		lista_cantidades = new int[100];
		ID_cliente = id_cliente;
		ID_comanda = ultimo_ID;
		ultimo_ID++;

	}

	/**
	 * Method to add a product to the list of products
	 * @param producto objecte
	 * @param cantidad int de la quantitat de productes
	 * @return TRUE if the product has been added to the list and FALSE if it
	 *         hasn't been added, that means it didn't fit in the list
	 */
	public boolean a�adir_producto(Producte producto, int cantidad) {

		if (numelem < lista_productos.length) {
			lista_productos[numelem] = producto;
			lista_cantidades[numelem] = cantidad;
			numelem++;
			return true;
		} else
			return false;

	}
	
	/**
	 * Method to eliminate a product of the order
	 * @param id_producto numero per identificar el producte
	 */
	public void eliminar_producto(int id_producto) {
		int i = 0;

		for (i = 0; i < numelem; i++) {

			if (lista_productos[i].getCodigo() == id_producto) {
				while (i < numelem) {
					lista_productos[i] = lista_productos[++i];
				}
			}
		}

	}
	
	/**
	 * Method to consult if a product is in the order by the ID of the product
	 * @param id_producte codi del producte
	 * @return the product if it is in the order or null if it isn't
	 */
	public boolean consultar_producte(int id_producte) {
		int i;
		for (i = 0; i < numelem; i++) {
			if (lista_productos[i].getCodigo() == id_producte) {
				return true;
			}
		}
		return false;
	}
	
	/**
	 * Method to calculate the final price of the order
	 * @param preferent boolea per saber si el client es preferent
	 * @return The price double
	 */
	public double calcular_preu(boolean preferent) {
		double precio_n = 0, precio_d = 0;
		int i;
		for (i = 0; i < numelem; i++) {
			precio_n = precio_n + (lista_productos[i].getPrecio() * lista_cantidades[i]);
		}

		if (preferent) {
			for (i = 0; i < numelem; i++) {
				precio_d = precio_d + (lista_productos[i].getPrecioConDescuento() * lista_cantidades[i]);
			}
			return precio_d;
		} else
			precio_d = precio_n; // per si fes un get del preu amb descompte que
									// es veigues que �s el mateix que sense
									// descompte
		return precio_n;
	}
	
	
	/**
	 * Method to confirm an order
	 */
	public void confirmar_comanda() {

		hora = new Date();
		toString();

	}

	/**
	 * Method toString
	 */
	@Override
	public String toString() {
		String productos_cantidades="";
		for (int i=0; i<numelem; i++){
			productos_cantidades+=lista_productos[i].toString();
			productos_cantidades+="\n Cantidad:";
			productos_cantidades+=lista_cantidades[i]+"\n";
		}
		return "Comanda "  + ID_comanda + " -  hora: "+df.format(hora)+ " - numelem= " + numelem + ",\nlista  de productos:\n" + productos_cantidades +  "PREU FINAL="
				+ preuFinal + " \nID_cliente=" + ID_cliente +  "\n\n";
	}

}
