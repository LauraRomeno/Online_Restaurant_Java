package Parte_funcional;

import java.io.*;
import java.util.*;
import java.text.*;



public class Main {
	
	/*Constantes para la lectura de ficheros*/
	static final int MAXRESTRICCIONES=3;
	static final int MAXCLIENTES=200;
	static final int MAXABSCOMANDAS=1000;
	static final int MAXPRODUCTOS=1000;
	static boolean sortir=false;
	
	static private Scanner scanchoice= new Scanner(System.in);

	
	/**
	 * M�todo para leer los datos de los clientes desde el main. Utilizamos ficheros de texto ya que la clase clientes 
	 * contiene multitud de datos que nos interesa poder manipular desde fuera del programa, a partir de un editor 
	 * de textos convencional.
	 * Estrucura por cliente: nombre;direcci�n;tel�fono;nombre de usuario;contrase�a;preferencia;restriccion(puede haber m�s de una, separadas por ;);*;producto;cantidad;(se repite por cada comanda);*;c�digo de comanda;(siguiente comanda);*;c�digo de comanda);"STOP\n"
	 * @author German Eizaguirre
	 * @param lista_clientes para la lista de clientes
	 * @param nombre_fichero	string nom del fitxer
	 * @param lista_productes llista de productes
	 * @param numero_productos int de n� de productes
	 * @throws IOException posible IOSException
	 * @throws ClassNotFoundException posible ClassNotFoundException
	 */
	public static int leer_clientes(String nombre_fichero, Client lista_clientes[], Object[] lista_productes, int numero_productos) throws IOException, ClassNotFoundException, ParseException{
		
				/*Tal y como est�n dise�adas las clases Client y Comanda, debemos trabajar con listas
				 * de comanda y de Llista_restricciones al asign�rlas a la lista de clientes
				 */
		
				Scanner lectorClientes= new Scanner (new File (nombre_fichero));
				//Variables para la lectura del fichero de clientes.
				int contador_comandas=0; 
				int numero_clientes=0;
				String controlador_secciones="*";	/*Centinela entre las Llista_restricciones y las comandas*/
				String fin_cliente="STOP";
				String nuevo_nom, nueva_adre�a, nuevo_telefon, nuevo_nomUsuari, nueva_contrasenya, nueva_restriccion;
				boolean nueva_preferencia;
				String nuevo_producto;
				int contador_productos;		/*Los productos estar�n listados por nombre*/
				boolean encontrado;
				Date nueva_hora;
				int nueva_cantidad, codigo_comanda;		/*Los productos ir�n acompa�ados de su cantidad, y las comandas de su c�digo
				 										(Las comandas deben ir acompa�adas de su c�digo porque si no el c�digo ser�a
				 										el asignado por el constructor a partir del est�tico, mientras que las comandas podr�an
				 										no haber sido realizadas en el orden en el que las leemos, que es de cliente en cliente*/
				
				DateFormat df = new SimpleDateFormat("HH:mm:ss"); /*Clase que permite crear un formato para la String de la hora*/
				Comanda[] nueva_comanda= new Comanda [MAXABSCOMANDAS];
				Llista_restricciones[] nuevas_restricciones= new Llista_restricciones[MAXCLIENTES];

				lectorClientes.useDelimiter(";");
				int counter=0;		/*Contador general de clientes*/
				while ((counter<MAXCLIENTES)&&(lectorClientes.hasNext())){
					
					lectorClientes.next();
					
					/*Lectura de los datos b�sicos de los clientes*/
					nuevo_nom=lectorClientes.next();
					nueva_adre�a=lectorClientes.next();
					nuevo_telefon=lectorClientes.next();
					nuevo_nomUsuari=lectorClientes.next();
					nueva_contrasenya=lectorClientes.next();
					nueva_preferencia= lectorClientes.nextBoolean();
					
					//Leer restricciones, que se guardar�n en la posici�n actual del vector de Llista_restricciones
					nuevas_restricciones[counter]= new Llista_restricciones(MAXRESTRICCIONES);
					nueva_restriccion=lectorClientes.next();
					while (!nueva_restriccion.equals(controlador_secciones)){
						nuevas_restricciones[counter].a�adir_restriccion(nueva_restriccion);
						nueva_restriccion=lectorClientes.next();
					}
					
					/*Guardamos los datos le�dos hasta ahora*/
					lista_clientes[counter]= new Client (nuevo_nom, nueva_adre�a, nuevo_telefon, nuevo_nomUsuari, nueva_contrasenya, nuevas_restricciones[counter]);
					lista_clientes[counter].setPreferencia(nueva_preferencia);
					
					nuevo_producto= lectorClientes.next();
					/*Leemos todas la comandas con sus productos y cantidades por separado*/
					while ((contador_comandas<MAXABSCOMANDAS)&&(!nuevo_producto.equals(fin_cliente))){
						nueva_comanda[contador_comandas]=new Comanda(counter+1);
						while (!nuevo_producto.equals(controlador_secciones)){
							nueva_cantidad=lectorClientes.nextInt();
							encontrado=false;
							contador_productos=0;
							while ((contador_productos<numero_productos)&&(encontrado==false)){
								/*Solo se a�adir�n los productos que est�n en la lista de productos*/
								if (((Producte) lista_productes[contador_productos]).getNombre().equals(nuevo_producto)){
									encontrado=true;
									if (lista_productes[contador_productos] instanceof Plato)
										nueva_comanda[contador_comandas].a�adir_producto((Plato)lista_productes[contador_productos], nueva_cantidad);
									else 
										nueva_comanda[contador_comandas].a�adir_producto((Bebida)lista_productes[contador_productos], nueva_cantidad);
								}
								contador_productos++;
							}
							nuevo_producto= lectorClientes.next();
						}
						codigo_comanda=lectorClientes.nextInt();
						nueva_hora= df.parse(lectorClientes.next()); /*Lectura de la hora de la comanda*/
						nueva_comanda[contador_comandas].setHora(nueva_hora);
						nueva_comanda[contador_comandas].setID_comanda(codigo_comanda);
						nueva_comanda[contador_comandas].setPreuFinal((float)nueva_comanda[contador_comandas].calcular_preu(nueva_preferencia));
						lista_clientes[counter].afegirComanda(nueva_comanda[contador_comandas]);
						contador_comandas++;;
						nuevo_producto=lectorClientes.next();
					}
					numero_clientes++;
					counter++;
				}
				lectorClientes.close();
				return numero_clientes;
	}
	
	/**
	 * M�todo para guardar clientes en un fichero de texto, seg�n la estructura de datos fijada en 
	 * el m�todo para leer clientes.
	 * @author German Eizaguirre
	 * @param nombre_fichero nombre del fichero donde se guardar�n los datos.
	 * @param lista_clientes lista de clientes de los cuales se deben guardar los datos.
	 * @Param num_clientes int numero de clients
	 * @throws IOException posible excepci�n IO
	 */
	public static void guardarClientes (String nombre_fichero, Client[] lista_clientes, int num_clientes) throws IOException, ParseException{
		
		BufferedWriter saveClient= new BufferedWriter (new FileWriter(nombre_fichero));
		
		int contador_clientes=0;
		int contador2;
		int contador3;
		DateFormat df = new SimpleDateFormat("HH:mm:ss"); /*Clase que permite crear un formato para la String de la hora*/
		
		while (contador_clientes<num_clientes){
			
			/*Escribimos los datos b�sicos del cliente*/
			saveClient.write(lista_clientes[contador_clientes].getNom()+";"+lista_clientes[contador_clientes].getAdre�a()+";"
					+lista_clientes[contador_clientes].getTelefon()+";"+lista_clientes[contador_clientes].getNomUsuari()+";"+
					lista_clientes[contador_clientes].getContrasenya()+";"+lista_clientes[contador_clientes].getPreferencia()+";");
			
			/*Escribimos las restricciones*/
			contador2=0;
			while (contador2<lista_clientes[contador_clientes].getLista_restricciones().getSize()){
				saveClient.write(lista_clientes[contador_clientes].getLista_restricciones().getRestriccion(contador2)+";");
				contador2++;
			}
			saveClient.write("*;");
			
			contador2=0;
			while (contador2<lista_clientes[contador_clientes].getNumComandes()){
				contador3=0;
				while (contador3<lista_clientes[contador_clientes].getLista_comandas()[contador2].getNumelem()){
					saveClient.write(lista_clientes[contador_clientes].getLista_comandas()[contador2].getLista_productos()[contador3].getNombre()+";"+
							lista_clientes[contador_clientes].getLista_comandas()[contador2].getLista_cantidades()[contador3]+";");
					contador3++;
				}
				saveClient.write("*;"+lista_clientes[contador_clientes].getLista_comandas()[contador2].getID_comanda()+";"+df.format((lista_clientes[contador_clientes].getLista_comandas()[contador2].getHora()))+";");
				contador2++;
			}
			saveClient.write("STOP;\n");
			contador_clientes++;

		}
		saveClient.close();
	}

	/**
	 * M�todo para leer productos desde un fichero de texto.
	 * @author Oriol Villar� and German Eizaguirre
	 * @param nombre_fichero nom del fitcher 
	 * @param lista_productes llista d eproductes
	 * @return numero de productos registrados
	 * @throws IOException
	 * @throws ClassNotFoundException
	 */
	public static int leer_productos(String nombre_fichero, Producte[] lista_productes) throws IOException, ClassNotFoundException{
	
		Scanner lectorProductos= new Scanner (new File (nombre_fichero));
		
		int numero_productos=0;
		String nuevo_nom=null;
		String nuevo_tipus=null;
		String nueva_restriccion=" ";
		String controlador_secciones="*";	/*Conservem el mateix model de fitxer que per a clients*/
		int nuevo_volum=0;
		double nuevo_preu=0;
		int nuevo_descompte;
		boolean alcohol=false;
											
		Llista_restricciones[] nuevas_restricciones= new Llista_restricciones[MAXPRODUCTOS];
			lectorProductos.useDelimiter(";");
		int counter=0;	
		int counter2;
		
		/*Lectura de les dades del producte*/
		
		while ((counter<MAXPRODUCTOS)&&(lectorProductos.hasNext())){
			lectorProductos.next();//El c�digo lo asigna el constructor de producto
			nuevo_tipus=lectorProductos.next();
			
			if (nuevo_tipus.equals("PLAT")){
				nuevo_nom=lectorProductos.next();
				nuevo_preu=lectorProductos.nextFloat();
				nuevo_descompte=lectorProductos.nextInt();
				nuevas_restricciones[counter]= new Llista_restricciones(MAXRESTRICCIONES);
				nueva_restriccion=lectorProductos.next();
				while (!nueva_restriccion.equals(controlador_secciones)){
					nuevas_restricciones[counter].a�adir_restriccion(nueva_restriccion);
					nueva_restriccion=lectorProductos.next();
				}
				
			}
			else {
				nuevo_nom=lectorProductos.next();
				nuevo_preu=lectorProductos.nextDouble();
				nuevo_descompte=lectorProductos.nextInt();
				nuevo_volum=lectorProductos.nextInt();
				alcohol=lectorProductos.nextBoolean();
			}
		
			/*Emmagatzemem les dades llegides*/
			if (nuevo_tipus.equals("PLAT")){
				lista_productes[counter]= new Plato (nuevo_nom, nuevo_preu, nuevo_descompte);
				counter2=0;
				while (counter2<nuevas_restricciones[counter].getSize()){
					((Plato)lista_productes[counter]).a�adirRestriccion(nuevas_restricciones[counter].getRestriccion(counter2));
					counter2++;
				}
			}
			else if (nuevo_tipus.equals("BEBIDA")){ 
				lista_productes[counter]= new Bebida (nuevo_nom, nuevo_preu, nuevo_descompte, nuevo_volum, alcohol);
			}
			numero_productos++;
			counter++;
			
		}
		lectorProductos.close();
		return numero_productos;
		
	}
		
		
	public static void guardarProductos (String nombre_fichero, Producte[] lista_productos, int num_productos) throws IOException{
		
		BufferedWriter saveProduct= new BufferedWriter (new FileWriter(nombre_fichero));
		
		int contador_productos=0;
		
		while(contador_productos<num_productos){
			
			/*Buscamos si el producto es un plato o una bebida.*/
			
			if (lista_productos[num_productos].getTipus().equals("PLAT")){						
				saveProduct.write(lista_productos[contador_productos].getNombre()+";"+lista_productos[contador_productos].getPrecio()+";"
				+lista_productos[contador_productos].getDescuento()+";"+((Plato)lista_productos[contador_productos]).getRestricciones()+";");
				}
				
			
			else {
				saveProduct.write(lista_productos[contador_productos].getNombre()+";"+lista_productos[contador_productos].getPrecio()+";"
				+lista_productos[contador_productos].getDescuento()+";"+((Bebida)lista_productos[contador_productos]).getVolumen()+";"
				+((Bebida)lista_productos[contador_productos]).getAlcohol()+";");
				}
			}

			saveProduct.write("STOP;");
			contador_productos++;

			saveProduct.close();
			
		}	
		
	
	public static Client login(Client[] lista_clientes, int numero_clientes){
				

				//Demanem el client
				boolean opcio_incorrecta=true;
			
				Client client= null;
				Llista_restricciones l_restricciones= new Llista_restricciones (MAXRESTRICCIONES);
				String auxiliar=null;
				int choiceentry;
				
				while (opcio_incorrecta==true){
					
					System.out.println("Ets nou client o ja tens compte?");
					System.out.println("1 - Ja tinc compte");
					System.out.println("2 - No tinc compte");
					choiceentry=scanchoice.nextInt();
					
					switch (choiceentry) {
						
						case 1 :
						
							scanchoice.nextLine();
							System.out.println("Nom d'usuari: ");
							auxiliar = scanchoice.nextLine();		//nom usuari
							int i=0;
							
							//TRY CATCH SI NO ES TROBA USUARI
							try{
							while ((i<numero_clientes)&&(opcio_incorrecta==true)){
								if (( lista_clientes[i]).getNomUsuari().equals(auxiliar)) opcio_incorrecta=false;
								else i++;
							}
							
							if (opcio_incorrecta==false){
								System.out.println("Contrasenya: ");
								auxiliar = scanchoice.nextLine();			//contrasenya
								
								if (!auxiliar.equals(lista_clientes[i].getContrasenya())){
									System.out.println("Contrasenya incorrecta");
									opcio_incorrecta=true;
								}
								else client=new Client(lista_clientes[i].getNom(), lista_clientes[i].getAdre�a(), lista_clientes[i].getTelefon(), lista_clientes[i].getNomUsuari(), lista_clientes[i].getContrasenya(), lista_clientes[i].getLista_restricciones());
								for(int contador_comandas=0; contador_comandas<lista_clientes[i].getNumComandes(); contador_comandas++){
									client.afegirComanda(lista_clientes[i].getLista_comandas()[contador_comandas]);
								}
							}	
							}
							catch(NullPointerException e){
							
								System.out.println("El usuari no existeix");
								}
							break;
							
							
						case 2 :
							
							boolean encontrado=false;
							scanchoice.nextLine();
							System.out.println("Nom d'usuari: ");
							auxiliar = scanchoice.nextLine();		//nom usuari
							int j=0;
						
							while ((j<numero_clientes)&&(encontrado==false)){
								if (((Client) lista_clientes[j]).getNomUsuari().equals(auxiliar)){
									encontrado=true;
								}
								j++;
							}
							if (encontrado==true)
								System.out.println("Nom d'usuari ja existent");
							else {
										
								System.out.println("Nom personal: ");
								String nom = scanchoice.nextLine();					//nompersonal
								System.out.println("Adre�a: ");
								String adre�a = scanchoice.nextLine();				//adre�a
								System.out.println("Tel�fon: ");
								String tel = scanchoice.nextLine();					//tel�fon
								System.out.println("Contrasenya: ");
								String contrasenya = scanchoice.nextLine();			//contrasenya
								
								//triar restriccions
								
								System.out.println("Ets celiac? (1-si 0-no) ");
								int alergic = scanchoice.nextInt();			//contrasenya
								if (alergic==1) l_restricciones.a�adir_restriccion("gluten");
								System.out.println("Ets alergic a la lactosa: ");
								alergic = scanchoice.nextInt();			//contrasenya
								if (alergic==1) l_restricciones.a�adir_restriccion("lactosa");
								System.out.println("Ets al�rgic als fruits secs: ");
								alergic = scanchoice.nextInt();			//contrasenya
								if (alergic==1) l_restricciones.a�adir_restriccion("nueces");
								
								client= new Client(nom, adre�a, tel, auxiliar, contrasenya, l_restricciones);	
								if (numero_clientes<MAXCLIENTES){
									lista_clientes[numero_clientes]=new Client(nom, adre�a, tel, auxiliar, contrasenya, l_restricciones);
								}
								opcio_incorrecta=false;
								scanchoice.nextLine();
							
							}
							break;
							
								
							default: System.out.println("Opci� incorrecta");break;
							
	
					}
				}
				return client;
		}
	
		public static boolean opciones (Client[] lista_clientes, int numero_clientes, Producte[] lista_productos, int numero_productos, Client cliente_actual){

			int choiceentry;
			boolean sortir=false;
			int codi;
			choiceentry= Integer.parseInt(scanchoice.nextLine());
			switch(choiceentry){
			
			case 1: 
				//afegim un producte al menu
				
					int i=0;
					boolean existe_producto=false;
					
					System.out.println("Escull plat o beguda:");
					
					String nom=scanchoice.nextLine();
					if (nom.equalsIgnoreCase("plat")){
						System.out.println("Introdueix el nom del plat: ");
						String plat=scanchoice.nextLine();
						while (i<numero_productos){
							if (((Producte) lista_productos[i]).getNombre().equals(plat)) existe_producto=true;
							i++;
						}
					
						if ((existe_producto==false)&&(numero_productos<MAXPRODUCTOS)){
							
								System.out.println("Introdueix el preu del plat: ");
								double pplat=scanchoice.nextDouble();
								System.out.println("Introdueix el descompte del plat: ");
								int dplat=scanchoice.nextInt();
								
								lista_productos[i]=new Plato(plat, pplat, dplat);
								numero_productos++;
								
								System.out.println("�Gluten?(1 - s�, 0 - no)");
								dplat=scanchoice.nextInt();
								if (dplat!=0){
									((Plato)lista_productos[i]).a�adirRestriccion("gluten");
								}
								System.out.println("�Nueces?(1 - s�, 0 - no)");
								dplat=scanchoice.nextInt();
								if (dplat!=0){
									((Plato)lista_productos[i]).a�adirRestriccion("nueces");
								}
								System.out.println("�Lactosa?(1 - s�, 0 - no)");
								dplat=scanchoice.nextInt();
								if (dplat!=0){
									((Plato)lista_productos[i]).a�adirRestriccion("lactosa");
								}
								scanchoice.nextLine();
							}
							else {
								if (existe_producto==true) System.out.println("El producte ya existeix");
								else System.out.println("No es possible guardar mes productes");
								scanchoice.nextLine();
							}
						}
					else {	
						
						if (nom.equalsIgnoreCase("Beguda")){
							System.out.println("Introdueix el nom de la beguda: ");
							String nbeguda=scanchoice.nextLine();
							while (i<numero_productos){
								if (((Producte) lista_productos[i]).getNombre().equals(nbeguda)) existe_producto=true;
								i++;
							}
						
							if ((existe_producto==false)&&(numero_productos<MAXPRODUCTOS)){
								System.out.println("Introdueix el preu de la beguda: ");
								double pbeguda=scanchoice.nextDouble();
								System.out.println("Introdueix el descompte de la begudat: ");
								int dbeguda=scanchoice.nextInt();
								System.out.println("Introdueix el volum en ml: ");
								int vbeguda=scanchoice.nextInt();
								System.out.println("Introdueix si �s alcoholica: (true/false)");
								boolean bbeguda=scanchoice.nextBoolean();
								
								lista_productos[i]=new Bebida(nbeguda, pbeguda, dbeguda, vbeguda, bbeguda);
								numero_productos++;
								scanchoice.nextLine();
							}
							else{
								if (existe_producto==true) System.out.println("El producte ya existeix");
								else System.out.println("No es possible guardar mes productes");
							}
						}
				 
					}
				
				break;
				
			case 2: 
				//Cargar productos de un fichero
				String nombre_fichero;
				int numero_anterior;
				System.out.println("Introdueix el nom del fitxer:");
				nombre_fichero=scanchoice.nextLine();
				try{
					numero_anterior=numero_productos;
					numero_productos= leer_productos(nombre_fichero, lista_productos);
					if (numero_anterior>numero_productos){
						for(int ct=numero_productos; ct<numero_anterior; ct++){
							lista_productos[ct]=null; 	/*Actualizamos la lista de productos para que solamente hayan disponibles los productos cargados desde el fichero*/
						}
					}
					
				}
				catch (IOException y){
					System.out.println("Error en lectura de productes");
				}
				catch (ClassNotFoundException w){
					System.out.println("Error en lectura de productes");
				}
				break;
				
			case 3:
				//Eliminar producto a partir de su c�digo.
				System.out.println("Insereixi el codi del producte que vol eliminar."); //esborrar dintre de la llista del main
				codi= Integer.parseInt(scanchoice.nextLine());
				
				int k=0;
				while (k<MAXPRODUCTOS){
					if (((Producte) lista_productos[k]).getCodigo()==codi) break;
					k++;
				}
				
				if (k==MAXPRODUCTOS) {
					 System.out.println("No existeix un producte que correspongui al codi inserit.");
				}
				else{
					while ((k < numero_productos)&&(k<MAXPRODUCTOS-1)) {
						lista_productos[k] = lista_productos[++k];
					}
					numero_productos--;
				}
							
				break;

			case 4:
				//Consultar info de un producto a partir de su c�digo
				
				System.out.println("Insereixi el codi del producte que vol consultar.");
				codi= Integer.parseInt(scanchoice.nextLine());
				
				k=0;
				while (k<numero_productos){
					if (((Producte) lista_productos[k]).getCodigo()==codi) break;
					k++;
				}
				
				if(k<numero_productos){
					if (lista_productos[k] instanceof Plato){
						System.out.println(((Plato)lista_productos[k]));
					}
					else  System.out.println(((Bebida)lista_productos[k]));
				}
				else System.out.println("No existeix un producte que correspongui al codi inserit.");
				break;
			
			case 5:
				//Listar las comandas realizadas por un cliente
				System.out.println(cliente_actual.llistarComandas());
				break;
			
			case 6:
				//obrir una comanda
				//dins de obrir comanda s'hauran d'afegir productes i crear la comanda sencera
				
				Comanda comanda=new Comanda(cliente_actual.getIdClient()); //creem una comanda
				
				boolean noficomanda=true;
				int codiproducte;
				int cantidadproducto;
				int contador1, contador2, contador3;
				boolean coincide_restriccion=false;
				DecimalFormat df = new DecimalFormat("0.00##");
				int editar=1;
				
				while (editar==1){
					while(noficomanda){
						System.out.println("1 - Afegir un nou producte a la comanda");
						System.out.println("2 - Eliminar un producte de la comanda");
						System.out.println("3 - Calcular preu");
						System.out.println("4 - Acabar comanda");
						int eleccio=scanchoice.nextInt();
						
						switch(eleccio){
							
						case 1: 
							
							System.out.println("Introdueix el codi del producte: ");
							codiproducte=scanchoice.nextInt();
							System.out.println("Introdueix la quantitat de productes amb el codi: "+codiproducte+"desitjes afegir a la comanda");
							cantidadproducto=scanchoice.nextInt();
							
							k=0;
							while (k<MAXPRODUCTOS){
								if (((Producte) lista_productos[k]).getCodigo()==codiproducte) break;
								k++;
							}
							
							if (k<MAXPRODUCTOS){
								comanda.a�adir_producto(lista_productos[k], cantidadproducto);
							}
							break;
							
						case 2:
							
							System.out.println("Introdueix el codi del producte a eliminar: ");
							int codieliminar=scanchoice.nextInt();
							comanda.eliminar_producto(codieliminar);
							
							//fer try i catch per comprovar que hi ha el producte a la comanda
							break;
							
						case 3:
							double preu=comanda.calcular_preu(cliente_actual.getPreferencia());
							System.out.println("El pru de la comanda �s: "+df.format(preu));
							
							break;
							
						case 4:
							noficomanda=false;
							
							break;
						}

					}
					
					//PANTALLA RESUMEN DE LA COMANDA
					System.out.println("---------------PRODUCTOS");
					contador1=0;
					while (contador1<comanda.getNumelem()){
						System.out.println("\t"+comanda.getLista_productos()[contador1]);
						System.out.println("cantidad: "+comanda.getLista_cantidades()[contador1]);
						//Opcional: mostrar que hay restricci�n
						if (comanda.getLista_productos()[contador1] instanceof Plato){
							contador2=0;
							coincide_restriccion=false;
							while ((contador2<((Plato)comanda.getLista_productos()[contador1]).getNumeroRestricciones())&&(coincide_restriccion==false)){
								contador3=0;
								while ((contador3<cliente_actual.getLista_restricciones().getSize())&&(coincide_restriccion==false)){
									if (((Plato)comanda.getLista_productos()[contador1]).getRestricciones().getRestriccion(contador2).equals(cliente_actual.getLista_restricciones().getRestriccion(contador3)))
											coincide_restriccion=true;
									contador3++;
								}
								contador2++;
							}
	
						}
						if (coincide_restriccion==true){
							System.out.println("\tATENCION: cumple una Restricci�n alimentaria!");
						}
						contador1++;
					}
					//FIN PANTALLA RESUMEN COMANDA
					
					System.out.println("�Vols editar la comanda? 0 - no");
					editar= scanchoice.nextInt();
					if (editar==0){
						comanda.confirmar_comanda();
						cliente_actual.afegirComanda(comanda);
						System.out.println("La comanda ha estat realitzada");
					}
					else noficomanda=true;
					scanchoice.nextLine();
				}
				
				break;
				
			case 7:
				
				//copiar comanda
				int contador81, contador82, contador83;
				boolean coincide_restriccion8=false;
				int enviar_si;
				Comanda comanda8= new Comanda(cliente_actual.getIdClient());
				
				cliente_actual.llistarComandas();
				System.out.println("Introdueix el codi de la comanda que vols copiar");
				int comandacopiar=scanchoice.nextInt();
				
				int p=0;
				while (p<cliente_actual.getNumComandes()){
					if (comandacopiar==cliente_actual.getLista_comandas()[p].getID_comanda()){
						comanda8=cliente_actual.getLista_comandas()[p];
						break;
					}
					p++;
				}
				
				//PANTALLA RESUMEN DE LA COMANDA
				System.out.println("----------PRODUCTO");
				contador81=0;
				while (contador81<comanda8.getNumelem()){
					System.out.println("\t"+comanda8.getLista_productos()[contador81]);
					System.out.println("cantidad: "+comanda8.getLista_cantidades()[contador81]);
					
					//Opcional: mostrar que hay restricci�n
					if (comanda8.getLista_productos()[contador81] instanceof Plato){
						contador82=0;
						coincide_restriccion8=false;
						while ((contador82<((Plato)comanda8.getLista_productos()[contador81]).getNumeroRestricciones())&&(coincide_restriccion8==false)){
							contador83=0;
							while ((contador83<cliente_actual.getLista_restricciones().getSize())&&(coincide_restriccion8==false)){
								if (((Plato)comanda8.getLista_productos()[contador81]).getRestricciones().getRestriccion(contador82).equals(cliente_actual.getLista_restricciones().getRestriccion(contador83)))
										coincide_restriccion8=true;
								contador83++;
							}
							contador82++;
						}

					}
					if (coincide_restriccion8==true){
						System.out.println("\tATENCION: cumple una Restricci�n alimentaria!");
					}
					contador81++;
				}
				
				enviar_si=scanchoice.nextInt();
				if (enviar_si!=0){
					comanda8.confirmar_comanda();
					cliente_actual.afegirComanda(comanda8);
					System.out.println("La comanda ha estat realitzada");
				}
				else System.out.println("No se ha realizado la comanda");
				//FIN PANTALLA RESUMEN COMANDA
				
				break;
				
			case 8:
				//Se leen clientes y comandas de los clientes de un mismo fichero
				String nombre_fichero_nuevo_leer;
				
				nombre_fichero_nuevo_leer= scanchoice.nextLine();
				try{
					numero_clientes= leer_clientes(nombre_fichero_nuevo_leer, lista_clientes, lista_productos, numero_productos);
				}
				catch (IOException a){
					System.out.println("Error en lectura de clientes");
				}
				catch (ClassNotFoundException d){
					System.out.println("Error en lectura de clientes");
				}
				catch(ParseException lol){
					System.out.println("Error en lectura de clientes");
				}
				System.out.println("Comandes i clients carregats des de fitxer.");
				break;
				
			case 9:
				/*Guardar datos clientes y comandas (un solo fichero)*/
				String nombre_fichero_nuevo_guardar=" ";
				System.out.println("Introdueix el nom del fitxer");
				nombre_fichero_nuevo_guardar= scanchoice.nextLine();
				try {
					guardarClientes(nombre_fichero_nuevo_guardar, lista_clientes, numero_clientes);
				}
				catch (IOException t){
					System.out.println("Error en guardat de clients");
				}
				catch (ParseException lol){
					System.out.println("Error en guardat de clients");
				}
				/*Guardar datos clientes y comandas, un solo fichero*/
				break;
				
			case 10: sortir=true;
					break;
					
			default: System.out.println("Opci� incorrecta");
			
			}
			
			return sortir;
		}
		

		public static void main(String[] args) {
			
			Producte[] lista_productes= new Producte[MAXPRODUCTOS];
			Client[] lista_clientes= new Client [MAXCLIENTES];
			Client cliente_actual;
			int numero_clientes=0;
			int numero_productos=0;
	
		//LECTURA INICIAL FICHERO PREDETERMINADO
		
		try{
			numero_productos= leer_productos("listaProductos.txt", lista_productes);
			numero_clientes = leer_clientes("listaClientes.txt", lista_clientes, lista_productes, numero_productos);
		}
		catch(IOException w){
			System.out.println("Error en la lectura inicial");
		}
		catch(ClassNotFoundException i){
			System.out.println("Error en la lectura inicial");
		}
		catch (ParseException lol){
			System.out.println("Error en la lectura inicial");
		}

		//FIN LECTURA INCIAL FICHERO PREDETERMINADO
		
		cliente_actual= login (lista_clientes, numero_clientes);
		
		while(sortir==false){
			
		System.out.println("Quina opci� vol triar?:");
		System.out.println("1 - Afegir un producte al men�"); 
		System.out.println("2 - Carregar els productes d'un fitxer."); 
		System.out.println("3 - Eliminar un producte."); 
		System.out.println("4 - Consultar la informaci� d'un producte.");
		System.out.println("5 - Llistar totes les comandes d'un client."); 
		System.out.println("6 - Obrir una comanda.");
		System.out.println("7 - Copiar una comanda anterior."); 
		System.out.println("8 - Carregar les comandes i els clients d'un fitxer"); 
		System.out.println("9 - Guardar la informaci�.");
		System.out.println("10 - Sortir");
		
		sortir= opciones (lista_clientes, numero_clientes, lista_productes, numero_productos, cliente_actual);

		}
		scanchoice.close();
		}

		/**
		 * @return the maxrestricciones
		 */
		public static int getMaxrestricciones() {
			return MAXRESTRICCIONES;
		}

		/**
		 * @return the maxclientes
		 */
		public static int getMaxclientes() {
			return MAXCLIENTES;
		}

		/**
		 * @return the maxabscomandas
		 */
		public static int getMaxabscomandas() {
			return MAXABSCOMANDAS;
		}

		/**
		 * @return the maxproductos
		 */
		public static int getMaxproductos() {
			return MAXPRODUCTOS;
		}
		
		
		
	}
