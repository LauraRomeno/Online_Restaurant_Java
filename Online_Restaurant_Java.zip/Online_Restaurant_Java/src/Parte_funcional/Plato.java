/** 
 * Clase plato
 * 
 * @author German Telmo Eizaguirre Suarez
 * 
 */
package Parte_funcional;

public class Plato extends Producte {
	
	private final int maximo_restricciones=20;
	Llista_restricciones Llista_R;
	private final String tipus="P";
	
	/**
	 * Constructor para la clase plato.
	 * @param new_nombre nombre del plato
	 * @param new_precio precio del plato (en euros)
	 * @param new_descuento posible descuento del plato sobre 100
	 */
	public Plato (String new_nombre, double new_precio, int new_descuento){
		super(new_nombre, new_precio, new_descuento);
		Llista_R=new Llista_restricciones(maximo_restricciones);
	}
	
	/**
	 * M�todo para a�adir una restricci�n al plato.
	 * @param new_restrict String de la nueva restricci�n a a�adir
	 * @return true si se a�ade correctamente - false si no se pueden a�adir m�s restricciones
	 */
	public boolean a�adirRestriccion (String new_restrict){
		
		boolean correcto=false;
		if (Llista_R.getSize()<maximo_restricciones){
			Llista_R.a�adir_restriccion(new_restrict);
			correcto=true;
		}
		return correcto;
	}
	
	/**
	 * M�todo p�ra obtener todas las restricciones que tiene el plato.
	 * @return instancia de una lista de restricciones con las restricciones del Plato
	 */
	public Llista_restricciones getRestricciones (){
		Llista_restricciones listaDevolver= Llista_R.copy();
		return listaDevolver;
	}
	
	/**
	 * M�todo para obtener el tipo de producto (P de plato).
	 * @return "P" de plato
	 * 
	 */
	@Override
	public String getTipus (){
		return tipus;
	}
	
	/**
	 * M�todo para obtener el n�mero de restricciones del producto.
	 * @return n�mero de restricciones que tiene el producto
	 */
	public int getNumeroRestricciones (){
		return Llista_R.getSize();
	}
	
	/**
	 * M�todo toString
	 */
	public String toString (){
		return (super.toString()+"\n Restricciones:"+Llista_R.toString());
	}
	
}
