package interficieGrafica;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

/**
 * Clase JDialog que recoge los datos para el registro de un usuario.
 * Se instancia desde una PANTALLA1
 * @author German Eizaguirre
 *
 */
public class RegisterInfo extends JDialog{

	private static final long serialVersionUID = 1L;	
	
	/*Declaramos la variables que formar�n el cuadro de di�logo*/
	/*Opciones para los JComboBox*/
	private String[] opciones= {"S�", "No"};
	/*Resto de variables*/
	 private JLabel userID, password, nombre_real, direccio, telefon, celiaco, lactosa, nueces;
	 private JTextField nombre_usuario, contrasenya, nombre, direccion, telefono;
	  JComboBox<String> celiacoBox, lactosaBox, nuecesBox;
	  
	  private boolean correcto=false;
	  
	  /**
	   * Constructor para el JDialog. Estructura la ventana e incorpora Listeners.
	   * @param mami PANTALLA1 que invoca el cuadro de di�logo.
	   */
	  public RegisterInfo (PANTALLA1 mami){
		  
		  /*Instanciamos los componentes del cuadro de di�logo*/
		  /*Etiquetas para indicar qu� dato introducir al usuario*/
		  userID= new JLabel ("ID:");
		  password= new JLabel ("Contrasenya:");
		  nombre_real= new JLabel ("Nom:");
		  direccio= new JLabel ("Direcci�:");
		  telefon= new JLabel ("Tel�fon:");
		  celiaco= new JLabel ("�Cel�ac?");
		  lactosa= new JLabel ("�Al�l�rgic a la lactosa?");
		  nueces= new JLabel ("�Al�l�rgic als nous?");
		  /*Campos rellenables de texto para cada etiqueta y JComboBoxes*/
		  nombre_usuario= new JTextField ();
		  contrasenya= new JTextField ();
		  nombre= new JTextField ();
		  direccion= new JTextField ();
		  telefono= new JTextField ();
		  celiacoBox=new JComboBox<> (opciones);
		  lactosaBox=new JComboBox<> (opciones);
		  nuecesBox=new JComboBox<> (opciones);
		  
		  /*Estructuramos el Dialog*/
			JPanel new_panel=  new JPanel();
			new_panel.setLayout(new GridLayout(9,2));
			new_panel.add(userID);
			new_panel.add(nombre_usuario);
			new_panel.add(password);
			new_panel.add(contrasenya);
			new_panel.add(nombre_real);
			new_panel.add(nombre);
			new_panel.add(direccio);
			new_panel.add(direccion);
			new_panel.add(telefon);
			new_panel.add(telefono);
			new_panel.add(celiaco);
			new_panel.add(celiacoBox);
			new_panel.add(lactosa);
			new_panel.add(lactosaBox);
			new_panel.add(nueces);
			new_panel.add(nuecesBox);
			
			/*Botones para aceptar y cancelar introducci�n de texto*/
		    JButton Aceptar = new JButton("Aceptar");
		    JButton Cancelar = new JButton("Cancel�lar");
		    
		    /*Panel para los botones*/
		    JPanel botones = new JPanel(new FlowLayout());
		    botones.add(Aceptar);
		    botones.add(Cancelar);

		    /*Establecemos ambos elementos principales en el container del cuadro de di�logo*/
		    Container c = getContentPane();
		    c.add(new_panel, BorderLayout.NORTH);
		    c.add(botones, BorderLayout.SOUTH);
		    
		    /*Establecemos los Listeners, que determinan que le usuario haya pulsado 'OK' o no (Como se explica en la clase LogINInfo*/
		   Aceptar.addActionListener( new ActionListener() {
		           public void actionPerformed(ActionEvent e) {
		               correcto = true;
		               setVisible(false);
		           }
		        });
		    Cancelar.addActionListener( new ActionListener() {
		           public void actionPerformed(ActionEvent e) {
		               correcto = false;
		               setVisible(false);
		           }
		        });
		    
		    /*Ajustamos, modalizamos (bloqueamos resto de ventanas cuando el JDialog est� activo) y visibilizamos el cuadro de di�logo*/
		    pack();
		    setModal(true);
		    setVisible(true);
	  }
	  
	  /**
	   * M�todo para saber si el usuario a pulsado 'OK'.
	   * @return correcto==true si el usuario ha pulsado 'OK', si no correcto==false
	   */
	  public boolean datosBien (){
		  return correcto;
	  }
	  
	  /**
	   * M�todo para obtener el nombre de usuario intoducido.
	   * @return contenido del JTextField 'nombre_usuario'
	   */
	  public String getID(){
		  return nombre_usuario.getText();
	  }
	  
	  /**
	   * M�todo para obtener la contrase�a introducida por el usuario.
	   * @return contenido del JTextField 'contrasenya'
	   */
	  public String getContrasenya(){
		  return contrasenya.getText();
	  }
	  
	  /**
	   * M�todo para obtener el nombre real del usuario.
	   * @return contenido del JTextField 'nombre'
	   */
	  public String getNombre(){
		  return nombre.getText();
	  }
	  
	  /**
	   * M�todo para obtener la direcci�n del usuario.
	   * @return contenido del JTextFiel 'direccion'
	   */
	  public String getDireccion (){
		  return direccion.getText();
	  }
	  
	  /**
	   * M�todo para obtener el n�mero de tel�fono del usuario.
	   * @return contenido del JTextField 'telefono'
	   */
	  public String getTelefono(){
		  return telefono.getText();
	  }
	  
	  /**
	   * M�todo para obtener si el usuario es al�rgico o no al gluten.
	   * @return contenido de la JComboBox celiacoBox ("S�" si es al�rgico, "No" si no lo es)
	   */
	  public String getCeliaco(){
		  Object seleccion= celiacoBox.getSelectedItem();
		  return seleccion.toString();
	  }
	  
	  /**
	   * M�todo para obtener si el usuario es al�rgico o no a la lactosa.
	   * @return contenido de la JComboBox lactosaBox ("S�" si es al�rgico, "No" si no lo es)
	   */
	  public String getLactosa(){
		  Object seleccion= lactosaBox.getSelectedItem();
		  return seleccion.toString();
	  }
	  
	  /**
	   * M�todo para obtener si el usuario es al�rgico o no a las nueces.
	   * @return contenido de la JComboBox nuecesBox ("S�" si es al�rgico, "No" si no lo es)
	   */
	  public String getNueces(){
		  Object seleccion= nuecesBox.getSelectedItem();
		  return seleccion.toString();
	  }
}
