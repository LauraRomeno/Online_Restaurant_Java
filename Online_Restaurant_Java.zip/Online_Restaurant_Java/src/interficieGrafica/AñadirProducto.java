package interficieGrafica;

import java.awt.event.*;

/**
 * Clase Listener para a�adir Plato o Bebida.
 * Se llama desde los botones a�adir Plato o Bebida de la PANTALLA( (visualizaci�n a�adir producto)
 * @author German Eizaguirre
 *
 */
public class A�adirProducto implements ActionListener{
	
	private PANTALLA8 Window;
	private int opcion;
	
	/**
	 * Constructor del Listener.
	 * @param nueva_window PANTALLA8 que llama al Listener
	 * @param opcion 1: a�adir Plato / 2: a�adir Bebida
	 */
	public A�adirProducto (PANTALLA8 nueva_window, int opcion) {
		Window = nueva_window;
		this.opcion=opcion;
	}
	
	/**
	 * M�todo de evento (cuando se clicka bot�n) llama a funci�n afegirProducte de la PANTALLA8 con el m�todo seleccionado.
	 */
	public void actionPerformed(ActionEvent evt) {
		
		Window.afegirProducte(opcion);
	}

}
