package interficieGrafica;

import java.awt.event.*;

/**
 * Clase Listener que llama a la funci�n de salir del programa de la PANTALLA1 que lo invoca.
 * Se utiliza en el bot�n de salir.
 * @author German Eizaguirre
 *
 */
public class ExitListener implements ActionListener {
	
	PANTALLA1 WindowQueLlama;
	
	/**
	 * Contructor del Listener.
	 * @param aWindow PANTALLA1 desde la que se invoca el Listener
	 */
	public ExitListener (PANTALLA1 aWindow) {
		WindowQueLlama = aWindow;
	}
	
	/**
	 * M�todo de evento, llama a funci�n Salir() de PANTALLA1.
	 */
	public void actionPerformed(ActionEvent evt) {
		
		WindowQueLlama.Salir();
	}

}
