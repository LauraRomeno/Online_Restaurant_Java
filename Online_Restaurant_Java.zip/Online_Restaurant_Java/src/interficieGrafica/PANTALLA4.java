package interficieGrafica;

import javax.swing.*;

import Parte_funcional.Client;
import Parte_funcional.Comanda;
import Parte_funcional.Plato;
import Parte_funcional.Producte;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
/**
 * Classe que implementa la Pantalla4 que cont� 4 botos (afegir productes, eliminar productes, acabar comanda i mostrar preu)
 * 2 caselles per introduir codi i producte a afegir o eliminar
 * i 2 requadres, un que cont� la llista de productes disponibles i l
 * @author Cinta, Laura i Maite
 *
 */
public class PANTALLA4 extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	Container comanda = getContentPane();
	final JButton add, finish, delete, calculate;
	final JTextField codiProducte, quantitat;
	final JLabel llistat, LabelPreu;
	private float preu = 0;
	int codiProducte1, quantitat1;
	Client client;
	Comanda comanda1;
	
	public PANTALLA4(Producte[] lista_productos, int num_productes, Client cliente_actual) {
		super("New order");
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setContentPane(comanda);
		setBounds(0, 0, 500, 200);
		// Comanda comanda1=new Comanda(cliente_actual.getIdClient()); //creem
		// una comanda
		comanda.setLayout(new GridLayout(4, 2));

		llistat = new JLabel("llista de productes:" + llistarProductes(lista_productos, num_productes));
		add = new JButton("Add product");
		codiProducte = new JTextField("codi");
		delete = new JButton("Delet product");
		quantitat = new JTextField("quantitat");
		finish = new JButton("Finish order");
		calculate = new JButton("Calculate price");
		LabelPreu = new JLabel(preu + "�");
		client = cliente_actual;

		comanda.add(llistat);
		comanda.add(codiProducte);
		comanda.add(add);
		comanda.add(quantitat);
		comanda.add(calculate);
		comanda.add(LabelPreu);
		comanda.add(finish);
		comanda.add(delete);

		setVisible(true);
		PANTALLA6 pantalla6=new PANTALLA6(lista_productos, comanda1);
		
		DialegPantalla4(this, comanda1, client, lista_productos, num_productes, pantalla6);
		

	}
	
	
	
	public void DialegPantalla4(PANTALLA4 p4, Comanda comanda1, Client client, Producte[] lista_productos,
			int num_products , PANTALLA6 p6) {

		p4.getAdd().addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				codiProducte1 = Integer.parseInt(p4.getCodiProducte().getText());
				
				quantitat1 = Integer.parseInt(p4.getQuantitat().getText());
				
				int i = 0;
				while (i < num_products) {
					if ((lista_productos[i]).getCodigo() == (codiProducte1))
						break;
					i++;
				}
				Producte producte_afegir;

				if (lista_productos[i] instanceof Plato) {

					producte_afegir = lista_productos[i];

				} else {

					producte_afegir = lista_productos[i];
				}
				comanda1.a�adir_producto(producte_afegir, quantitat1);
				System.out.println("");

			}
		});

		p4.getDelete().addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				codiProducte1 = Integer.parseInt(p4.getCodiProducte().getText());
				quantitat1 = Integer.parseInt(p4.getQuantitat().getText());

				comanda1.eliminar_producto(codiProducte1);

			}

		});

		p4.getFinish().addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				p4.setVisible(false);
				PANTALLA6 pantalla6=new PANTALLA6( lista_productos ,comanda1);
				pantalla6.setVisible(true);

			}
		});

		p4.getCalculate().addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				double preu1 = comanda1.calcular_preu(client.getPreferencia());
				p4.setPreu(preu1);

			}
		});
	}

	public String llistarProductes(Producte[] lista_productos, int num_productes) {
		String llista = "";

		for (int i = num_productes - 1; i >= 0; i--) {
			llista = (llista + "\n" + lista_productos[i].toString());
		}
		return llista;
	}

	

	/**
	 * @return the add
	 */
	public JButton getAdd() {
		return add;
	}

	/**
	 * @param preu1
	 *            the preu to set
	 */
	public void setPreu(double preu1) {
		this.preu = (float) preu1;
	}

	/**
	 * @return the finish
	 */
	public JButton getFinish() {
		return finish;
	}

	/**
	 * @return the delete
	 */
	public JButton getDelete() {
		return delete;
	}

	/**
	 * @return the calculate
	 */
	public JButton getCalculate() {
		return calculate;
	}

	/**
	 * @return the codiProducte
	 */
	public JTextField getCodiProducte() {
		return codiProducte;
	}

	/**
	 * @return the quantitat
	 */
	public JTextField getQuantitat() {
		return quantitat;
	}

}
