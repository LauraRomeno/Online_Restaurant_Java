package interficieGrafica;

import java.awt.event.*;

/**
 * Clase listener para iniciar el proceso de identificaci�n de un cliente existente.
 * Se llama desde el bot�n 'Login' de una PANTALLA1 
 * @author German Eizaguirre
 *
 */
public class LogINListener implements ActionListener {
	
	PANTALLA1 WindowQueLlama;
	
	/**
	 * Constructor del listener.
	 * @param aWindow PANTALLA! desde la que se invoca el Listener
	 */
	public LogINListener (PANTALLA1 aWindow) {
		WindowQueLlama = aWindow;
	}
	
	/**
	 * M�todo actionPerformed de evento, llama a iniciarLogIN() de PANTALLA1.
	 */
	public void actionPerformed(ActionEvent evt) {
		
		WindowQueLlama.IniciarLogIN();
	}

}
