package interficieGrafica;

import java.awt.event.*;

/**
 * Clase Listener para la opci�n de registro de un nuevo cliente.
 * Se llama desde una PANTALLA1 y llama a la funci�n IniciarRegistro().
 * @author German Eizaguirre
 *
 */
public class RegisterListener implements ActionListener {
	
	PANTALLA1 WindowQueLlama;
	
	/**
	 * Constructor para el Listener.
	 * @param aWindow PANTALLA1 desde la que se invoca el Listener.
	 */
	public RegisterListener (PANTALLA1 aWindow) {
		WindowQueLlama = aWindow;
	}
	
	/**
	 * M�todo de evento para el Listener.
	 */
	public void actionPerformed(ActionEvent evt) {
		
		WindowQueLlama.IniciarRegistro();
	}

}
