package interficieGrafica;

import java.awt.event.*;

/**
 * Clase Listener para eliminar un Producto.
 * Se llama desde una PANTALLA8.
 * @author German Eizaguirre
 *
 */
public class eliminar_plat implements ActionListener{
	
	private PANTALLA8 Window;

	/**
	 * Constructor del Listener.
	 * @param nueva_window PANTALLA8 desde la que se llama al Listener.
	 */
	public eliminar_plat (PANTALLA8 nueva_window) {
		Window = nueva_window;

	}
	
	/**
	 * M�todo de evento que llama a funci�n delete() de la PANTALLA8.
	 */
	public void actionPerformed(ActionEvent evt) {	
		Window.delete();
	}

}
