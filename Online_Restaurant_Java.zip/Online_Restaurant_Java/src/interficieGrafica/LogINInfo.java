package interficieGrafica;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

/**
 * Clase JDialog para obtener los datos del Log In del usuario.
 * Se llama desde PANTALLA1
 * @author German Eizaguirre
 */
public class LogINInfo extends JDialog{

		private static final long serialVersionUID = 1L;	
		
	/*Declaraci�n de las variables que compondr�n el JDialog*/
	private JLabel  identificador, password;
	  private JTextField  IDusuario, contrasenya;
	  
	  /*Determinar� que el usuario haya pulsado el bot�n de 'OK'*/
	  private boolean correcto=false;
	
	  /**
	   * Constructor para el JDialog. Coloca componentes y pide la informaci�n al usuario.
	   * @param papi instancia de PANTALLA1 desde la cual se invoca el JDialog.
	   */
	public LogINInfo (PANTALLA1 papi){
		
		super(papi, "Log In");
		
		/*Se crean las instancias de los componentes de la JDialog*/
		identificador=new JLabel ("Nombre usuario:");
		password= new JLabel ("Contrase�a:");
		IDusuario=new JTextField(10);
		contrasenya=new JTextField(10);
		
		/*Estructuramos la ventana*/
		JPanel new_panel=  new JPanel();
		new_panel.setLayout(new GridLayout(4,2));

		new_panel.add(identificador);
		new_panel.add(IDusuario);
		new_panel.add(password);
		new_panel.add(contrasenya);
		
		 /*Botones para aceptar y cancelar la introducci�n de informaci�n por parte del usuario*/
	    JButton Aceptar = new JButton("Aceptar");
	    JButton Cancelar = new JButton("Cancel�lar");
	    
	    /*Para mejorar la estructuraci�n, creamos un panel aislado para los botones*/
	    JPanel botones = new JPanel(new FlowLayout());
	    botones.add(Aceptar);
	    botones.add(Cancelar);

	    Container c = getContentPane();
	    c.add(new_panel, BorderLayout.NORTH);
	    c.add(botones, BorderLayout.SOUTH);
	    
	    /*Asignamos los Listeners a los botones.*/
	   Aceptar.addActionListener( new ActionListener() {
	           public void actionPerformed(ActionEvent e) {
	               correcto = true;
	               setVisible(false);
	               /*El listener de aceptar pasar� 'correcto' a true, lo que determinar� que el usuario ha considerado
	                * apropiados los datos introducidos y quiere comenzar el Log In
	                */
	           }
	        });
	    Cancelar.addActionListener( new ActionListener() {
	           public void actionPerformed(ActionEvent e) {
	               correcto = false;
	               setVisible(false);
	           }
	        });

	    /*Establecemos las �ltimas caracter�sticas del JDialog*/
	    /*Lo ajustamos al contenido*/
	    pack();
	    /*Bloqueamos el resto de ventanas cuando el di�logo est� activado*/
	    setModal(true);
	    /*Lo visibilizamos*/
	    setVisible(true);
		
	}
	
	/**
	 * M�todo para obtener la contrase�a introducida por el usuario.
	 * @return String del contenido del JTextField contrasenya.
	 */
	public String getContrase�a (){
		return contrasenya.getText();
	}
	
	/**
	 * M�todo para obtener el nombre de usuario introducido.
	 * @return String del contenido del JTextField IDusuario
	 */
	public String getIDusuario(){
		return IDusuario.getText();
	}
	
	/**
	 * M�todo para saber si el usuario ha pulsado OK.
	 * @return contenido del booleano 'correcto'
	 */
	public boolean getDatosInsertados(){
		return correcto;
	}
}
