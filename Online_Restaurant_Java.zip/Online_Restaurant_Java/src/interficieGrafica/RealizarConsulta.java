package interficieGrafica;

import java.awt.event.*;

/**
 * Clase Listener para el bot�n de consulta de un producto.
 * Se llama desde una PANTALLA8.
 * @author German Eizaguirre
 *
 */
public class RealizarConsulta implements ActionListener{
	
	private PANTALLA8 Window;
	
	/**
	 * Constructor del Listener.
	 * @param nueva_window PANTALLA8 desde la que se invoca el Listener.
	 */
	public RealizarConsulta (PANTALLA8 nueva_window) {
		Window = nueva_window;

	}
	
	/**
	 * M�todo de evento. Llama al m�todo consultar() de la PANTALLA8.
	 */
	public void actionPerformed(ActionEvent evt) {	
		Window.consultar();
	}

}
