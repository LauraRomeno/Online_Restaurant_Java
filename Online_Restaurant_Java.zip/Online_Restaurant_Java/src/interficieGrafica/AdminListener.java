package interficieGrafica;

import java.awt.event.*;

/**
 * Clase Listener para el bot�n de administrador, que llama al m�todo correspondiente de PANTALLA1
 * (que generar� una ventana de administrador)
 * @author German Eizaguirre
 *
 */
public class AdminListener implements ActionListener {
	
	PANTALLA1 WindowQueLlama;
	
	/**
	 * Constructor del Listener.
	 * @param aWindow PANTALLA1 desde la que se invoca el Listener
	 */
	public AdminListener (PANTALLA1 aWindow) {
		WindowQueLlama = aWindow;
	}
	
	/**
	 * M�todo de evento, llama a IniciarAdmin() de PANTALLA1
	 */
	public void actionPerformed(ActionEvent evt) {
		
		/*Llama a la funci�n IniciarAdmin de la PANTALLA1 (pantalla de inici� de sesi�n) desde la que se invoque el listener*/
		WindowQueLlama.IniciarAdmin();
	}

}
