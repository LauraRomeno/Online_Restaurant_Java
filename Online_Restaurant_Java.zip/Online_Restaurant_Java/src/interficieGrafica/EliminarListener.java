package interficieGrafica;

import java.awt.event.*;

/**
 * Clase Listener para abrir la visualizaci�n de eliminar productos.
 * Se llama desde el bot�n de eliminar productos de la PANTALLA7.
 * @author German Eizaguirre
 *
 */
public class EliminarListener implements ActionListener{
	
	private PANTALLA7 Window;
	
	/**
	 * Constructor de Listener.
	 * @param nueva_window PANTALLA7 desde la que se llama al Listener.
	 */
	public EliminarListener (PANTALLA7 nueva_window) {
		Window = nueva_window;
	}
	
	/**
	 * M�todo de evento, cuando se clicka el bot�n de eliminar llama al m�todo gestionarProductos(int opcion) con la opci�n 2,
	 * activando la visualizaci�n de eliminar.
	 */
	public void actionPerformed(ActionEvent evt) {
		
		Window.gestionarProductos(2);
	}

}
