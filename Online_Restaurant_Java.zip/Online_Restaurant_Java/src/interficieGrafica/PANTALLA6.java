package interficieGrafica;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import Parte_funcional.*;

public class PANTALLA6 extends JFrame {
	private static final long serialVersionUID = 1L;
	JButton confirmarC,backC;
	
	public PANTALLA6(Producte[] lista_product, Comanda comanda) {
	/*Declaraci�n dels botons*/
	super("Confirm order");
	confirmarC=new JButton ("Confirm order");
	backC=new JButton ("Go back");
	JLabel productesC=new JLabel ();
	JLabel totalC=new JLabel ("Total"+comanda.getNumelem());
	
	Container myContainer = getContentPane();
	myContainer.setLayout(new GridLayout(2,2));
	
	myContainer.add(productesC);
	myContainer.add(totalC);
	myContainer.add(backC);
	myContainer.add(confirmarC);
	
	
	}
	
	
	/*A�ade los listener para determinar que se ha pulsado 'OK'*/
	 public void dialegPantalla6 (PANTALLA4 p4,Comanda comanda,Producte[] lista_product){
	confirmarC.addActionListener( new ActionListener() {
           public void actionPerformed(ActionEvent e) {
               comanda.confirmar_comanda();
               setVisible(false);
           }
        });
   backC.addActionListener( new ActionListener() {
           public void actionPerformed(ActionEvent e) {
               p4.setVisible(true);
               setVisible(false);
           }
        });
	 }
}
