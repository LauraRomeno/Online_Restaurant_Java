package interficieGrafica;

import java.awt.*;
import javax.swing.*;

import Parte_funcional.*;

/**
 * Clase inicial de la Interficie Gr�fica, en la que el usuario puede hacer tres cosas:
 * Iniciar sesi�n con una cuenta existente, registrarse con una nueva cuenta o gestionar los productos como administrador (opci�n que
 * cumple la parte opcional de a�adir consultar o eliminar productos de la IG)
 * @author German Eizaguirre
 */
public class PANTALLA1  extends JFrame{
	
	private static final long serialVersionUID = 1L;
	
	private Client [] Wlista_clientes; /*Se referenciar� a la lista de clientes del frame para ser actualizada si es necesario.*/
	private int Wnum_clientes;
	private Client Wcliente_actual= null;
	private Producte[] Wlista_productes;
	private int Wnum_productos;

	/**
	 * Constructor para la pantalla 1, que muestra cuatro botones; uno para iniciar sesi�n, otro para registrarse, otro para gestionar los productos como administrador
	 * y un �ltimo para salir (cerrar el programa).
	 * @param titol T�tulo general de la ventana que se genera
	 * @param lista_clientes lista de clientes perteneciente al programa principal
	 * @param numero_clientes numero de clientes en la lista
	 * @param cliente_actual cliente actual (usuario) en caso de que no sea administrador
	 * @param lista_productos lista de productos disponibles
	 * @param numero_productos numero de productos en la lista
	 */
	public PANTALLA1 (String titol, Client[] lista_clientes, int numero_clientes, Client cliente_actual, Producte[] lista_productos, int numero_productos){
		
		/*Declaraci�n de los botones*/
		super("Benvingut al nostre restaurant");
		JButton loginB=new JButton ("Log in");
		JButton registrarB=new JButton ("Nou usuari");
		JButton adminB=new JButton ("Administrador");
		JButton salirB=new JButton ("Sortir");
		
		/*Estructuraci�n de la ventana*/
		Container logINcontainer = getContentPane();
		logINcontainer.setLayout(new GridLayout(4,1));
		logINcontainer.add(loginB);
		logINcontainer.add(registrarB);
		logINcontainer.add(adminB);
		logINcontainer.add(salirB);
		
		/*Obtenci�n datos clientes y productos (primero se obtienen las referencias a los objetos y luego la propia lista del main se referencia a la lista 
		 * que se modificar� en las ventanas)*/
		Wlista_clientes= new Client[lista_clientes.length];
		for (int n=0; n<numero_clientes; n++)
			Wlista_clientes[n]= lista_clientes[n];
		
		Wlista_productes=new Producte[lista_productos.length];
		for (int i=0; i<numero_productos; i++){
			Wlista_productes[i]=lista_productos[i];
		}

		lista_clientes=Wlista_clientes;
		Wnum_clientes=numero_clientes;
		cliente_actual=Wcliente_actual;
		lista_productos=Wlista_productes;
		Wnum_productos=numero_productos;
		
		/*Activaci�n ventana*/
		setDefaultCloseOperation(HIDE_ON_CLOSE);
		setSize(200,400);
		setVisible(true);
		
		/*Asignaci�n de listeners*/
		loginB.addActionListener(new LogINListener(this));
		registrarB.addActionListener(new RegisterListener(this));
		adminB.addActionListener(new AdminListener(this));
		salirB.addActionListener(new ExitListener(this));

  }
	

  /**
   * M�todo que permite relizar el registro de un nuevo cliente, llamando a una JDialog.
   */
  public void IniciarRegistro (){
	  
	  	/*Primero comprueba que hay sitio para m�s clientes*/
		if (Wnum_clientes<Wlista_clientes.length){
			
			/*Genera una nueva ventana de di�logo*/
			RegisterInfo RegDialog= new RegisterInfo(this);
			/*Comprueba que el usuario haya pulsado OK (se explica en la clase RegisterInfo)*/
			
			if (RegDialog.datosBien()){
				/*Comprueba que no haya campos vac�os*/
				
				if (RegDialog.getID().isEmpty()||RegDialog.getContrasenya().isEmpty()||RegDialog.getNombre().isEmpty()||RegDialog.getDireccion().isEmpty()||RegDialog.getTelefono().isEmpty()||
						RegDialog.getID().equals(" ")||RegDialog.getContrasenya().equals(" ")||RegDialog.getNombre().equals(" ")||RegDialog.getDireccion().equals(" ")||RegDialog.getTelefono().equals(" ")){
					JOptionPane.showMessageDialog(this, "Existeixen espais buits", "ATENCI�", JOptionPane.WARNING_MESSAGE);
				}
				
				else{
					/*Utiliza comprobarRegistro para saber si el cliente existe*/
					if (comprobarRegistro (RegDialog.getID())==Wnum_clientes){
						/*Crea la lista de posibles restriciones que se asignar� al cliente*/
						Llista_restricciones nueva_lista= new Llista_restricciones(3);
						/*A�ade restricciones seg�n el contenido de las JComboBox*/
						if (RegDialog.getCeliaco().equals("S�")) nueva_lista.a�adir_restriccion("gluten");
						if (RegDialog.getLactosa().equals("S�")) nueva_lista.a�adir_restriccion("lactosa");
						if (RegDialog.getNueces().equals("S�")) nueva_lista.a�adir_restriccion("nueces");
						/*Crea una nueva instancia de cliente al final de la lista*/
						Wlista_clientes[Wnum_clientes]= new Client(RegDialog.getNombre(), RegDialog.getDireccion(), RegDialog.getTelefono(), RegDialog.getID(), RegDialog.getContrasenya(),
								nueva_lista);
						/*Actualiza el cliente actual*/
						Wcliente_actual=Wlista_clientes[Wnum_clientes];
						/*Actualiza el numero de cliente*/
						Wnum_clientes++;
						JOptionPane.showMessageDialog(this, "Benvingut a la comunitat");
						PANTALLA2 pantalla2=new PANTALLA2(Wcliente_actual, Wlista_productes,Wnum_productos);
						pantalla2.setVisible(true);
						//(siguiente programador)Llamamos a PANTALLA2, que recibe por referencia la lista de cliente, el n�mero de clientes, la lista de productos...
					}
					else JOptionPane.showMessageDialog(this, "El usuari ya existeix", "ATENCI�", JOptionPane.WARNING_MESSAGE);
				}
			}
			else {
				System.exit(0);
			}
			
		}else JOptionPane.showMessageDialog(this, "No es poden guardar m�s clients", "ATENCI�", JOptionPane.WARNING_MESSAGE);

  }
  
  /**
   * M�todo para comprobar si un cliente existe en la base de datos.
   * @param auxiliar nombre de usuario del cliente
   * @return si no existe devolver� el n�mero de clientes en la lista, si existe, su posici�n en la lista
   */
  public int comprobarRegistro (String auxiliar){
		
	  	boolean existe=false;
		int j=0;
	
		while ((j<Wnum_clientes)&&(existe==false)){
			if (((Client) Wlista_clientes[j]).getNomUsuari().equals(auxiliar)){
				existe=true;
			}
			else j++;
		}
		return j;
  }
  
  /**
   * M�todo para realizar el "Log in" de un cliente.
   */
  public void IniciarLogIN (){
	  
	  /*Primero comprueba que haya clientes en la lista*/
	  if (Wnum_clientes==0){
		  JOptionPane.showMessageDialog(this, "No hi ha clients registrats", "ATENCI�", JOptionPane.WARNING_MESSAGE);
		  /*Si no hay clientes, da la opci�n de registrarse*/
		  int option= JOptionPane.showConfirmDialog(this, "Vols registrar-te?", "Error en registre", JOptionPane.YES_NO_OPTION);
			if (option == JOptionPane.YES_OPTION) {
				IniciarRegistro();
			} else if (option == JOptionPane.NO_OPTION) {
				Salir();
			} 
			
	  }
	  else{
		  
		  /*Si hay clientes guardados, genera una JDialog para hacer el Log In de un cliente*/
		  LogINInfo preguntar_Login= new LogINInfo(this);
		
		  /*Nos servir� para saber la posici�n en la lista del cliente que quiere entrar al programa*/
		  int usuario_existente;
		  
		  /*El JDialog permite saber si el usuario ha pulsado OK*/
		if (preguntar_Login.getDatosInsertados()){
			
			/*Comprueba que no haya datos vac�os*/
			if(preguntar_Login.getIDusuario().equals(null)||preguntar_Login.getIDusuario().equals("")||preguntar_Login.getContrase�a().equals(null)||preguntar_Login.getContrase�a().equals(""))
				JOptionPane.showMessageDialog(this, "Existeixen espais buits", "ATENCI�", JOptionPane.WARNING_MESSAGE);
			
			else{
				/*Comprueba que el cliente exista*/
				usuario_existente= comprobarRegistro (preguntar_Login.getIDusuario());
				if (usuario_existente!=Wnum_clientes){
					/*Comprueba que la contrase�a introducida por el cuadro de di�logo es correcta*/
					if (preguntar_Login.getContrase�a().equals(Wlista_clientes[usuario_existente].getContrasenya())){
						JOptionPane.showMessageDialog(this, "HOLA CARACOLA");
						/*Referencia el cliente actual a la posici�n de la lista correspondiente*/
						Wcliente_actual= Wlista_clientes[usuario_existente];
						//(Siguiente programador(Llamamos a PANTALLA2, que recibe por referencia la lista de cliente, el n�mero de clientes, la lista de productos...
					}
					else JOptionPane.showMessageDialog(this, "Contrasenya incorrecta", "ATENCI�", JOptionPane.WARNING_MESSAGE);
				}	
				else {
					JOptionPane.showMessageDialog(this, "El client no existeix", "ATENCI�", JOptionPane.WARNING_MESSAGE);
				}
			}
		}
	  } 
  }
  
  /**
   * M�todo que genera una nueva PANTALLA7, la cual muestra las opciones de administrador eliminar y a�adir producto (y estas a su vez consultar producto).
   */
   public void IniciarAdmin(){
	   
	   PANTALLA7 pantalla_administrador= new PANTALLA7(Wlista_productes, Wnum_productos);
	   pantalla_administrador.setVisible(true);
	   
   }
   
   /**
    * M�todo para salir del programa.
    */
   public void Salir(){
	   this.setVisible(false);
	  System.exit(0);
   }
   
   
}
