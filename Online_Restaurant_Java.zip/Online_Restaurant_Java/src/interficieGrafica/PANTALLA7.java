package interficieGrafica;

import java.awt.*;
import javax.swing.*;
import Parte_funcional.*;

/**
 * Clase JFrame para la pantalla del administrador, que dispondr� de las opciones de a�adir y eliminar productos
 * (adem�s de poder consultar productos en cada una de ellas).
 * @author German Eizaguirre
 *
 */
public class PANTALLA7 extends JFrame {
	
	private static final long serialVersionUID = 1L;
	
	/*Variables de contenido de datos*/
	private Producte[] Wlista_productos;
	private int Wnumero_productos;
	
	/**
	 * Constructor de la PANTALLA7
	 * @param lista_productos
	 * @param numero_productos
	 */
	public PANTALLA7 (Producte[] lista_productos, int numero_productos){
		
		super ("Gesti� de productes");
		
		/*Copiamos las referencias de cada producto*/
		Wlista_productos= new Producte [lista_productos.length];
		for (int i=0; i<numero_productos; i++){
			Wlista_productos[i]=lista_productos[i];
		}

		/*Pasamos la variable de la lista por referencia para poder editarla*/
		lista_productos=Wlista_productos;
		Wnumero_productos=numero_productos;
		
		/*Declaramos los componentes de la ventana*/
		JButton a�adirP= new JButton ("Afegir productess");
		JButton eliminarP= new JButton ("Eliminar productes");
		
		/*Establecemos el container y su dispoci�n (matricial)*/
		Container container= getContentPane();
		container.setLayout(new GridLayout(2,1));
		
		/*Incluimos los botones*/
		container.add(a�adirP);
		container.add(eliminarP);
		
		/*A�adimos listeners para los botones:
		 * a�adirP pasar� el valor 1 por su Listener, activando el modo de a�adir productos.
		 * eliminarP pasar� el valor 2 por su Listener, activando el modo de eliminar productos.*/
		a�adirP.addActionListener(new A�adirListener(this));
		eliminarP.addActionListener(new EliminarListener(this));
		
		/*�ltimas caracter�sticas de la JFrame: el modo de cerrarse, el tama�o y la visualizaci�n*/
		setDefaultCloseOperation(HIDE_ON_CLOSE);
		setSize(200,400);
		setVisible(true);	
	}
	
	/**
	 * M�todo que invoca a la JFrame de gesti�n de productos.
	 * @param queHacer 1 activar� la visualizaci�n de a�adir productos, 2 la visualizaci�n de eliminar productos.
	 */
	public void gestionarProductos(int queHacer){
		
		PANTALLA8 gestionWindow =new PANTALLA8 (queHacer, Wlista_productos, Wnumero_productos);
		gestionWindow.setVisible(true);
	}

}
