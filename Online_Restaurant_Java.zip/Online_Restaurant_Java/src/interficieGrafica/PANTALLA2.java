package interficieGrafica;
import Parte_funcional.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
/**
 * Classe que implementa la Pantalla2 que cont� 2 botons per elegir si la nova comanda es fa de zero o a partir d'una comanda anterior
 * @author Cinta, Laura i Maite
 *
 */
public class PANTALLA2 extends JFrame { //Clase de cont� la finestra
	private static final long serialVersionUID=1L;
	
	final Container contenidor;
	final JButton copia_comanda, nova_comanda;
	private Client Wcliente_actual= null;
	private Producte[] Wlista_productes;
	private int Wnum_productos;
	
/**
 * Constructor de a pantalla2
 * @param client client
 * @param lista_productos lista porductes
 * @param num_productes num productes
 */
	public PANTALLA2 (Client client, Producte[] lista_productos, int num_productes){
		super("Choose an action:");	//Construtor de JFrame se li passa el t�tol de la finestra
		setBounds(300,300,400,100);// Fixem la mida de JFrame setBoutons(x,y,altura,amplada)
		contenidor =getContentPane(); //Contenidor on hi haur� els botons
		contenidor.setLayout(new GridLayout(1,2)); 
		copia_comanda= new JButton("Copy a previous order");		//Creem els botons JButton ("text bot�")
		nova_comanda= new JButton("New order ");
		contenidor.add(copia_comanda);//Afegir botons la panell
		contenidor.add(nova_comanda);
		Wcliente_actual=client;
		Wlista_productes=lista_productos;
		Wnum_productos=num_productes;
		
		setVisible(true); //Mostrem la finestra		
		DialegPantalla2(this, lista_productos);
		
		
		
		
	}
	public void DialegPantalla2(PANTALLA2 p2, Producte[] lista_productos) { // (PANTALLA 4: FALTA PANTALLA LAURA
		PANTALLA3 p3 = new PANTALLA3(Wcliente_actual, lista_productos);
		p3.setVisible(false);
		PANTALLA4 p4 = new PANTALLA4(Wlista_productes, Wnum_productos, Wcliente_actual);
		p4.setVisible(false);
		p2.getCopia_comanda().addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				p3.setVisible(true);
				p2.setVisible(false);
			}
		});

		p2.getNova_comanda().addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				p4.setVisible(true);
				p2.setVisible(false);

			}
		});

	}

	
	
	
	



	/**
	 * @return the wcliente_actual
	 */
	public Client getWcliente_actual() {
		return Wcliente_actual;
	}




	/**
	 * @return the wlista_productes
	 */
	public Producte[] getWlista_productes() {
		return Wlista_productes;
	}




	/**
	 * @return the wnum_productos
	 */
	public int getWnum_productos() {
		return Wnum_productos;
	}




	/**
	 * @return the copia_comanda
	 */
	public JButton getCopia_comanda() {
		return copia_comanda;
	}




	/**
	 * @return the nova_comanda
	 */
	public JButton getNova_comanda() {
		return nova_comanda;
	}



}