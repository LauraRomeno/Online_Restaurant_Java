package interficieGrafica;

import java.io.*;
import java.util.*;

import Parte_funcional.Bebida;
import Parte_funcional.Client;
import Parte_funcional.Comanda;
import Parte_funcional.Llista_restricciones;
import Parte_funcional.Plato;
import Parte_funcional.Producte;

import java.text.*;



public class MainGraficas {
	
	/*Constantes para la lectura de ficheros*/
	static final int MAXRESTRICCIONES=3;
	static final int MAXCLIENTES=200;
	static final int MAXABSCOMANDAS=1000;
	static final int MAXPRODUCTOS=1000;

	
	/**
	 * M�todo para leer los datos de los clientes desde el main. Utilizamos ficheros de texto ya que la clase clientes 
	 * contiene multitud de datos que nos interesa poder manipular desde fuera del programa, a partir de un editor 
	 * de textos convencional.
	 * Estrucura por cliente: nombre;direcci�n;tel�fono;nombre de usuario;contrase�a;preferencia;restriccion(puede haber m�s de una, separadas por ;);*;producto;cantidad;(se repite por cada comanda);*;c�digo de comanda;(siguiente comanda);*;c�digo de comanda);"STOP\n"
	 * @author German Eizaguirre
	 * @param nombre_fichero nom del fitxer
	 * @param lista_clientes llista de clients
	 * @param lista_productes llista de productes
	 * @param numero_productos numero de productes
	 * @throws IOException posible IOSException
	 * @throws ClassNotFoundException posible ClassNotFoundException
	 * @throws ParseException ParseException
	 * @return numero_clientes nuemro de clients
	 */
	public static int leer_clientes(String nombre_fichero, Client lista_clientes[], Object[] lista_productes, int numero_productos) throws IOException, ClassNotFoundException, ParseException{
		
				/*Tal y como est�n dise�adas las clases Client y Comanda, debemos trabajar con listas
				 * de comanda y de Llista_restricciones al asign�rlas a la lista de clientes
				 */
		
				Scanner lectorClientes= new Scanner (new File (nombre_fichero));
				//Variables para la lectura del fichero de clientes.
				int contador_comandas=0; 
				int numero_clientes=0;
				String controlador_secciones="*";	/*Centinela entre las Llista_restricciones y las comandas*/
				String fin_cliente="STOP";
				String nuevo_nom, nueva_adre�a, nuevo_telefon, nuevo_nomUsuari, nueva_contrasenya, nueva_restriccion;
				boolean nueva_preferencia;
				String nuevo_producto;
				int contador_productos;		/*Los productos estar�n listados por nombre*/
				boolean encontrado;
				Date nueva_hora;
				int nueva_cantidad, codigo_comanda;		/*Los productos ir�n acompa�ados de su cantidad, y las comandas de su c�digo
				 										(Las comandas deben ir acompa�adas de su c�digo porque si no el c�digo ser�a
				 										el asignado por el constructor a partir del est�tico, mientras que las comandas podr�an
				 										no haber sido realizadas en el orden en el que las leemos, que es de cliente en cliente*/
				
				DateFormat df = new SimpleDateFormat("HH:mm:ss"); /*Clase que permite crear un formato para la String de la hora*/
				Comanda[] nueva_comanda= new Comanda [MAXABSCOMANDAS];
				Llista_restricciones[] nuevas_restricciones= new Llista_restricciones[MAXCLIENTES];

				lectorClientes.useDelimiter(";");
				int counter=0;		/*Contador general de clientes*/
				while ((counter<MAXCLIENTES)&&(lectorClientes.hasNext())){
					
					lectorClientes.next();
					
					/*Lectura de los datos b�sicos de los clientes*/
					nuevo_nom=lectorClientes.next();
					nueva_adre�a=lectorClientes.next();
					nuevo_telefon=lectorClientes.next();
					nuevo_nomUsuari=lectorClientes.next();
					nueva_contrasenya=lectorClientes.next();
					nueva_preferencia= lectorClientes.nextBoolean();
					
					//Leer restricciones, que se guardar�n en la posici�n actual del vector de Llista_restricciones
					nuevas_restricciones[counter]= new Llista_restricciones(MAXRESTRICCIONES);
					nueva_restriccion=lectorClientes.next();
					while (!nueva_restriccion.equals(controlador_secciones)){
						nuevas_restricciones[counter].a�adir_restriccion(nueva_restriccion);
						nueva_restriccion=lectorClientes.next();
					}
					
					/*Guardamos los datos le�dos hasta ahora*/
					lista_clientes[counter]= new Client (nuevo_nom, nueva_adre�a, nuevo_telefon, nuevo_nomUsuari, nueva_contrasenya, nuevas_restricciones[counter]);
					lista_clientes[counter].setPreferencia(nueva_preferencia);
					
					nuevo_producto= lectorClientes.next();
					/*Leemos todas la comandas con sus productos y cantidades por separado*/
					while ((contador_comandas<MAXABSCOMANDAS)&&(!nuevo_producto.equals(fin_cliente))){
						nueva_comanda[contador_comandas]=new Comanda(counter+1);
						while (!nuevo_producto.equals(controlador_secciones)){
							nueva_cantidad=lectorClientes.nextInt();
							encontrado=false;
							contador_productos=0;
							while ((contador_productos<numero_productos)&&(encontrado==false)){
								/*Solo se a�adir�n los productos que est�n en la lista de productos*/
								if (((Producte) lista_productes[contador_productos]).getNombre().equals(nuevo_producto)){
									encontrado=true;
									if (lista_productes[contador_productos] instanceof Plato)
										nueva_comanda[contador_comandas].a�adir_producto((Plato)lista_productes[contador_productos], nueva_cantidad);
									else 
										nueva_comanda[contador_comandas].a�adir_producto((Bebida)lista_productes[contador_productos], nueva_cantidad);
								}
								contador_productos++;
							}
							nuevo_producto= lectorClientes.next();
						}
						codigo_comanda=lectorClientes.nextInt();
						nueva_hora= df.parse(lectorClientes.next()); /*Lectura de la hora de la comanda*/
						nueva_comanda[contador_comandas].setHora(nueva_hora);
						nueva_comanda[contador_comandas].setID_comanda(codigo_comanda);
						nueva_comanda[contador_comandas].setPreuFinal((float)nueva_comanda[contador_comandas].calcular_preu(nueva_preferencia));
						lista_clientes[counter].afegirComanda(nueva_comanda[contador_comandas]);
						contador_comandas++;;
						nuevo_producto=lectorClientes.next();
					}
					numero_clientes++;
					counter++;
				}
				lectorClientes.close();
				return numero_clientes;
	}
	
	/**
	 * M�todo para guardar clientes en un fichero de texto, seg�n la estructura de datos fijada en 
	 * el m�todo para leer clientes.
	 * @author German Eizaguirre
	 * @param nombre_fichero nombre del fichero donde se guardar�n los datos.
	 * @param lista_clientes lista de clientes de los cuales se deben guardar los datos.
	 * @param num_clientes numero de clients 
	 * @throws IOException IOException
	 * @throws ParseException ParseException
	 */
	public static void guardarClientes (String nombre_fichero, Client[] lista_clientes, int num_clientes) throws IOException, ParseException{
		
		BufferedWriter saveClient= new BufferedWriter (new FileWriter(nombre_fichero));
		
		int contador_clientes=0;
		int contador2;
		int contador3;
		DateFormat df = new SimpleDateFormat("HH:mm:ss"); /*Clase que permite crear un formato para la String de la hora*/
		
		while (contador_clientes<num_clientes){
			
			/*Escribimos los datos b�sicos del cliente*/
			saveClient.write(lista_clientes[contador_clientes].getNom()+";"+lista_clientes[contador_clientes].getAdre�a()+";"
					+lista_clientes[contador_clientes].getTelefon()+";"+lista_clientes[contador_clientes].getNomUsuari()+";"+
					lista_clientes[contador_clientes].getContrasenya()+";"+lista_clientes[contador_clientes].getPreferencia()+";");
			
			/*Escribimos las restricciones*/
			contador2=0;
			while (contador2<lista_clientes[contador_clientes].getLista_restricciones().getSize()){
				saveClient.write(lista_clientes[contador_clientes].getLista_restricciones().getRestriccion(contador2)+";");
				contador2++;
			}
			saveClient.write("*;");
			
			contador2=0;
			while (contador2<lista_clientes[contador_clientes].getNumComandes()){
				contador3=0;
				while (contador3<lista_clientes[contador_clientes].getLista_comandas()[contador2].getNumelem()){
					saveClient.write(lista_clientes[contador_clientes].getLista_comandas()[contador2].getLista_productos()[contador3].getNombre()+";"+
							lista_clientes[contador_clientes].getLista_comandas()[contador2].getLista_cantidades()[contador3]+";");
					contador3++;
				}
				saveClient.write("*;"+lista_clientes[contador_clientes].getLista_comandas()[contador2].getID_comanda()+";"+df.format((lista_clientes[contador_clientes].getLista_comandas()[contador2].getHora()))+";");
				contador2++;
			}
			saveClient.write("STOP;\n");
			contador_clientes++;

		}
		saveClient.close();
	}

	/**
	 * M�todo para leer productos desde un fichero de texto.
	 * @author Oriol Villar� and German Eizaguirre
	 * @param nombre_fichero nom del fitxer
	 * @param lista_productes lista de productos
	 * @return numero de productos registrados
	 * @throws IOException IOException
	 * @throws ClassNotFoundException exepcio per la classe no trobada
	 */
	public static int leer_productos(String nombre_fichero, Producte[] lista_productes) throws IOException, ClassNotFoundException{
	
		Scanner lectorProductos= new Scanner (new File (nombre_fichero));
		
		int numero_productos=0;
		String nuevo_nom=null;
		String nuevo_tipus=null;
		String nueva_restriccion=" ";
		String controlador_secciones="*";	/*Conservem el mateix model de fitxer que per a clients*/
		int nuevo_volum=0;
		double nuevo_preu=0;
		int nuevo_descompte;
		boolean alcohol=false;
											
		Llista_restricciones[] nuevas_restricciones= new Llista_restricciones[MAXPRODUCTOS];
			lectorProductos.useDelimiter(";");
		int counter=0;	
		int counter2;
		
		/*Lectura de les dades del producte*/
		
		while ((counter<MAXPRODUCTOS)&&(lectorProductos.hasNext())){
			lectorProductos.next();//El c�digo lo asigna el constructor de producto
			nuevo_tipus=lectorProductos.next();
			
			if (nuevo_tipus.equals("PLAT")){
				nuevo_nom=lectorProductos.next();
				nuevo_preu=lectorProductos.nextFloat();
				nuevo_descompte=lectorProductos.nextInt();
				nuevas_restricciones[counter]= new Llista_restricciones(MAXRESTRICCIONES);
				nueva_restriccion=lectorProductos.next();
				while (!nueva_restriccion.equals(controlador_secciones)){
					nuevas_restricciones[counter].a�adir_restriccion(nueva_restriccion);
					nueva_restriccion=lectorProductos.next();
				}
				
			}
			else {
				nuevo_nom=lectorProductos.next();
				nuevo_preu=lectorProductos.nextDouble();
				nuevo_descompte=lectorProductos.nextInt();
				nuevo_volum=lectorProductos.nextInt();
				alcohol=lectorProductos.nextBoolean();
			}
		
			/*Emmagatzemem les dades llegides*/
			if (nuevo_tipus.equals("PLAT")){
				lista_productes[counter]= new Plato (nuevo_nom, nuevo_preu, nuevo_descompte);
				counter2=0;
				while (counter2<nuevas_restricciones[counter].getSize()){
					((Plato)lista_productes[counter]).a�adirRestriccion(nuevas_restricciones[counter].getRestriccion(counter2));
					counter2++;
				}
			}
			else if (nuevo_tipus.equals("BEBIDA")){ 
				lista_productes[counter]= new Bebida (nuevo_nom, nuevo_preu, nuevo_descompte, nuevo_volum, alcohol);
			}
			numero_productos++;
			counter++;
			
		}
		lectorProductos.close();
		return numero_productos;
		
	}
		
		public static void main(String[] args) {
			
			Producte[] lista_productes= new Producte[MAXPRODUCTOS];
			Client[] lista_clientes= new Client [MAXCLIENTES];
			Client cliente_actual=null;
			int numero_clientes=0;
			int numero_productos=0;
	
		//LECTURA INICIAL FICHERO PREDETERMINADO
		
		try{
			numero_productos= leer_productos("listaProductos.txt", lista_productes);
			numero_clientes = leer_clientes("listaClientes.txt", lista_clientes, lista_productes, numero_productos);
		}
		catch(IOException w){
			System.out.println("Error en la lectura inicial");
		}
		catch(ClassNotFoundException i){
			System.out.println("Error en la lectura inicial");
		}
		catch (ParseException lol){
			System.out.println("Error en la lectura inicial");
		}

		//FIN LECTURA INCIAL FICHERO PREDETERMINADO
		
		PANTALLA1 pantalla_inicial= new PANTALLA1("Benvingut", lista_clientes, numero_clientes, cliente_actual, lista_productes, numero_productos);
		pantalla_inicial.setVisible(true);
		
	}
}
