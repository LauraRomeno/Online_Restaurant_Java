package interficieGrafica;

import java.awt.event.*;

/**
 * Clase Listener para la activaci�n de la ventana de a�adir Productos
 * Se llama desde el bot�n de a�adir productos de la PANTALLA7.
 * @author German Eizaguirre
 *
 */
public class A�adirListener implements ActionListener{
	
	private PANTALLA7 Window;
	
	/**
	 * Constructor del Listener.
	 * @param nueva_window PANTALLA7 desde la que se llama al Listener
	 */
	public A�adirListener (PANTALLA7 nueva_window) {
		Window = nueva_window;
	}
	
	/**
	 * M�todo de evento, pasa el valor 1 al m�todo gestionarProductos, activando la pantalla de a�adir.
	 */
	public void actionPerformed(ActionEvent evt) {
		
		Window.gestionarProductos(1);
	}

}
