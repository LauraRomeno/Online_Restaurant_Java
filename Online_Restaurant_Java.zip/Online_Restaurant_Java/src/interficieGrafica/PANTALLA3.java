package interficieGrafica;
import Parte_funcional.*;
import javax.swing.*;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * Classe que implementa la Pantalla3 que cont� un requadre per introduir el codi de la comanda a repetir , una llista de totes les comandes previes del client i un bot� de validaci�
 * @author Cinta, Laura i Maite
 *
 */
public class PANTALLA3 extends JFrame {
	private static final long serialVersionUID=1L;
	final JButton repetir_comanda; //Botons
	final JTextField textCodi;
	final Container contenidor;
	final JLabel textcomandes;
	Comanda comanda1;
	

/**
 * Constructor de la pantalla3
 * @param client
 */
	public PANTALLA3(Client client, Producte[] lista_productos){
		
		super("Copiar comanda:");	//Construtor de JFrame se li passa el t�tol de la finestra
		setBounds(300,300,400,400);// Fixem la mida de JFrame setBoutons(x,y,altura,amplada)
		contenidor =getContentPane(); //Contenidor on hi haur� els botons
		contenidor.setLayout(new BorderLayout()); 
		textcomandes= new JLabel("Introduce de cody order in the top"+client.llistarComandas()); 		//Creem els botons JButton ("text bot�")
		textCodi= new JTextField(""); 
		repetir_comanda= new JButton("Repeat order");
		contenidor.add(repetir_comanda,BorderLayout.SOUTH );
		contenidor.add(textcomandes, BorderLayout.CENTER );
		contenidor.add(textCodi, BorderLayout.NORTH);
		
		//comanda1=client.getLista_comandas()[i];
		
		setVisible(true); //Mostrem la finestra
		
		setVisible(true);
		PANTALLA6 pantalla6=new PANTALLA6(lista_productos, comanda1);
		DialegPantalla3(pantalla6);
		
	}

	public void DialegPantalla3 (PANTALLA6 p6){ 
		
		repetir_comanda.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
					p6.setVisible(true);	
					 setVisible(false);
					 //codi=Integer.parseInt(p3.getTextCodi().getText()); //
				}
				}
			);
		

	}

	
	public static long getSerialversionuid() {
		return serialVersionUID;
	}



	public JButton getRepetir_comanda() {
		return repetir_comanda;
	}



	public JTextField getTextCodi() {
		return textCodi;
	}



	public Container getContenidor() {
		return contenidor;
	}



	public JLabel getTextcomandes() {
		return textcomandes;
	}


}
