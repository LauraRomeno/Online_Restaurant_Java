package interficieGrafica;

import java.awt.*;
import javax.swing.*;
import Parte_funcional.*;

/**
 * Clase JFrame para a�adir/eliminar productos.
 * Se llama desde una PANTALLA7 de un administrador.
 * @author German Eizaguirre
 *
 */
public class PANTALLA8 extends JFrame {

	private static final long serialVersionUID = 1L;
	
	/*Tipo pantalla determinar� si a�adir o eliminar productos*/
	private int tipo_pantalla;
	
	/*Variables de guardado de datos*/
	private Producte[] Wlista_productos;
	private int Wnumero_productos;
	
	/*Posibles componentes de la ventana*/
	private JTextArea Area_productos;
	private JTextField introCode;
	private JButton consultarB, a�adir_plato, a�adir_bebida, eliminar_plato;
	private JPanel panelDer;
	
	/**
	 * Constructor que abrir� la visualizaci�n de eliminar o a�adir productos seg�n
	 * el c�digo que se le pase como par�metro.
	 * @param QueHacer Int que determina ventana: 1: a�adir / 2: eliminar
	 * @param lista_productos lista que contiene los objetos Producte (PLatos y Bebidas)
	 * @param numero_productos numero de elementos en la lista
	 */
	public PANTALLA8 (int QueHacer, Producte[] lista_productos, int numero_productos){
		
		super("Gestionar productes");
		
		/*Primero se determina qu� visualizaci�n activar*/
		tipo_pantalla=QueHacer;
		
		/*Procesamiento de datos guardados*/
		Wlista_productos=new Producte[lista_productos.length];
		for (int i=0; i<numero_productos; i++){
			Wlista_productos[i]=lista_productos[i];
		}

		lista_productos=Wlista_productos;
		Wnumero_productos=numero_productos;
		
		/*Instancia los campos comunes a ambas visualizaciones*/
		Area_productos=new JTextArea();
		introCode= new JTextField();
		consultarB= new JButton("Consultar producte");
		panelDer= new JPanel();
		
		/*Estructura la visualizaci�n general de la ventana*/
		Container container= getContentPane();
		container.setLayout(new GridLayout(2,1));
		JPanel panel_area=new JPanel();
		panel_area.add(Area_productos);
		container.add(panel_area);
		
		/*A�adimos el Listener de consulta*/
		consultarB.addActionListener(new RealizarConsulta (this));
		
		/*CASO 1: Pantalla de a�adir productos*/
		if (tipo_pantalla==1){
			
			/*Estructuramos el segundo panel, que obtiene los botones y el JTextField
			 * para consultar productos seg�n su c�digo.
			 */
			panelDer.setLayout(new GridLayout(4,1));
			a�adir_plato=new JButton("Afegir plat");
			a�adir_bebida= new JButton ("Afegir beguda");
			panelDer.add(introCode);
			panelDer.add(consultarB);
			
			/*Tendr� dos botones, uno para a�adir Productes de la subclase Plato y otro para a�adir Bebida,
			 * ya que Producte es abstracto y no se puede instanciar.
			 */
			panelDer.add(a�adir_plato);
			panelDer.add(a�adir_bebida);
			container.add(panelDer);
			
			/*A�adimos los Listeners para cada bot�n*/
			a�adir_plato.addActionListener(new A�adirProducto(this, 1));
			a�adir_bebida.addActionListener(new A�adirProducto(this, 2));
			
			this.setVisible(true);
			
		}
		/*CASO 2: Pantalla de eliminar producto*/
		else{
			
			/*Seguimos los mismos pasos que en el CASO 1, pero ahora habr� un bot�n de eliminar producto*/
			panelDer.setLayout(new GridLayout(3,1));
			eliminar_plato=new JButton("Suprimir plat");
			eliminar_plato.addActionListener(new eliminar_plat(this));
			panelDer.add(introCode);
			panelDer.add(consultarB);
			panelDer.add(eliminar_plato);
			container.add(panelDer, BorderLayout.CENTER);
			this.setVisible(true);
		}
		
		/*�ltimas caracter�sticas generales del JFrame*/
		pack();
		this.setSize(500, 300);
		this.setDefaultCloseOperation(HIDE_ON_CLOSE);
	}
	
	/**
	 * M�todo para a�adir un producto introducido por el usuario a la lista.
	 * Muestra al usuario la pantalla apropiada para Plato/Bebida
	 * @param opcion si opcion==1, se a�ade un Plato, si opcion==2, se a�ade una Bebida.
	 */
	public void afegirProducte(int opcion){
		
		/*OPCI�N A�ADIR PLATO*/
		if (opcion==1){
			
			/*Genera un nuevo cuadro de di�logo para recoger los datos necesarios para a�adir un plato*/
			NuevoPlatoInfo PlatoDialog= new NuevoPlatoInfo(this);
			
			/*Si el usuario pulsa 'OK'*/
			if (PlatoDialog.datosBien()){
				/*Comprueba que no haya campos vac�os*/
				if ((PlatoDialog.getNombre()==null)||(PlatoDialog.getPrecio()==null)||(PlatoDialog.getDescuento()==null)||
						PlatoDialog.getNombre().equals("")||PlatoDialog.getPrecio().equals("")||PlatoDialog.getDescuento().equals("")){
					JOptionPane.showMessageDialog(this, "Existeixen espais buits", "ATENCI�", JOptionPane.WARNING_MESSAGE);
				}
				
				else{
					
					/*Comprueba que el plato no exista ya*/
					if (comprobarNombre (PlatoDialog.getNombre())==false){
						
						/*A�ade el plato a la lista, con sus correspondientes restricciones*/
						Wlista_productos[Wnumero_productos]= new Plato(PlatoDialog.getNombre(), Double.parseDouble(PlatoDialog.getPrecio()), Integer.parseInt(PlatoDialog.getDescuento()));
						if (PlatoDialog.getCeliaco().equals("S�")) ((Plato)Wlista_productos[Wnumero_productos]).a�adirRestriccion("gluten");
						if (PlatoDialog.getLactosa().equals("S�")) ((Plato)Wlista_productos[Wnumero_productos]).a�adirRestriccion("lactosa");
						if (PlatoDialog.getNueces().equals("S�")) ((Plato)Wlista_productos[Wnumero_productos]).a�adirRestriccion("nueces");
						Wnumero_productos++; /*Actualiza el n�mero de productos*/
					}
					else JOptionPane.showMessageDialog(this, "Ya existeix el producte", "ATENCI�", JOptionPane.WARNING_MESSAGE);
				}
			}
			
		}
		/*OPCI�N A�ADIR BEBIDA*/
		else{
			
			/*Genera un nuevo cuadro de di�logo para recoger los datos necesarios para a�adir una Bebida*/
			NuevaBebidaInfo BebidaDialog= new NuevaBebidaInfo(this);
						
			/*Comprueba el 'OK'*/
			if (BebidaDialog.datosBien()){
				/*Comprueba que no haya campos vac�os*/
				if ((BebidaDialog.getNombre()==null)||(BebidaDialog.getPrecio()==null)||(BebidaDialog.getDescuento()==null)||(BebidaDialog.getVolumen()==null)||
						BebidaDialog.getNombre().equals("")||BebidaDialog.getPrecio().equals("")||BebidaDialog.getDescuento().equals("")||BebidaDialog.getVolumen().equals("")){
					JOptionPane.showMessageDialog(this, "Existeixen espais buits", "ATENCI�", JOptionPane.WARNING_MESSAGE);
				}
				else{
					/*Comprueba que no haya productos con el mismo nombre y a�ade la Bebida a la lista*/
					if (comprobarNombre (BebidaDialog.getNombre())==false){
						boolean alcohol=false;
						if (BebidaDialog.getAlcohol().equals("S�")) alcohol=true;
						Wlista_productos[Wnumero_productos]= new Bebida(BebidaDialog.getNombre(), Double.parseDouble(BebidaDialog.getPrecio()), Integer.parseInt(BebidaDialog.getDescuento()), Integer.parseInt(BebidaDialog.getVolumen()), alcohol);							
						Wnumero_productos++;
					}
					else JOptionPane.showMessageDialog(this, "Ya existeix el producte", "ATENCI�", JOptionPane.WARNING_MESSAGE);
				}
			}
		}
	}
	
	/**
	 * M�todo para comprobar que un producto no tiene el mismo nombre.
	 * @param nombre String con el nombre del producto
	 * @return boolean true: existe el producto / false: no existe
	 */
	public boolean comprobarNombre(String nombre){
		
		boolean existe_producto=false;
		int i=0;
		while (i<Wnumero_productos){
			if (((Producte) Wlista_productos[i]).getNombre().equals(nombre)) existe_producto=true;
			i++;
		}
		 return existe_producto;
	}
	
	/**
	 * M�todo para consultar un producto, es decir, mostrar sus datos or pantalla (en una JTextArea).
	 */
	public void consultar (){
		
		/*Comprueba que el usuario haya introducido algo*/
		if ((!introCode.getText().equals(null))&&(!introCode.getText().equals(""))){
			
			/*Convierte el texto en un entero*/
			int codigo = Integer.parseInt(introCode.getText());
			int k=0;
			
			/*Comprueba que haya alg�n producto con el c�digo*/
			while (k<Wnumero_productos){
				if (((Producte) Wlista_productos[k]).getCodigo()==codigo) break;
				k++;
			}
			
			/*Si hay un producto con el c�digo, lo muestra por la text �rea, seg�n su tipo (Plato o Bebida)*/
			if(k<Wnumero_productos){
				if (Wlista_productos[k] instanceof Plato){
					Area_productos.setText(((Plato)Wlista_productos[k]).toString());
				}
				else  Area_productos.setText(((Bebida)Wlista_productos[k]).toString());
			}
			else JOptionPane.showMessageDialog(this, "El producte no existeix", "ATENCI�", JOptionPane.WARNING_MESSAGE);
		}
		else JOptionPane.showMessageDialog(this, "Introdueix un codi", "ATENCI�", JOptionPane.WARNING_MESSAGE);
	}
	
	/**
	 * M�todo para eliminar un producto de la lista, a partir de su c�digo introducido en un JTextField por el usuario.
	 */
	public void delete (){
		
		/*Obtenemos el c�digo desde el JTextField*/
		int codigo = Integer.parseInt(introCode.getText());
		int k=0;
		
		/*Verifica que el producto existe*/
		while (k<Wnumero_productos){
			if (((Producte) Wlista_productos[k]).getCodigo()==codigo) break;
			k++;
		}
		
		if (k==Wnumero_productos) {
			JOptionPane.showMessageDialog(this, "No existeix el producte", "ATENCI�", JOptionPane.WARNING_MESSAGE);
		}
		else{
			/*Si el producto existe lo elimina de la lista, eliminando su referencia*/
			while ((k < Wnumero_productos)&&(k<Wlista_productos.length-1)) {
				Wlista_productos[k] = Wlista_productos[++k];
			}
			Wnumero_productos--;
		}
	}
	
}
