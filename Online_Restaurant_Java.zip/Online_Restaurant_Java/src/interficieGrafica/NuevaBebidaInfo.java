package interficieGrafica;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

/**
 * Clase JDialog para a�adir una Bebida nueva.
 * Se llama en PANTALLA8.
 * @author German Eizaguirre
 *
 */
public class NuevaBebidaInfo extends JDialog{

	private static final long serialVersionUID = 1L;	
	
	/*Opciones del campo alchol*/
	private String[] opciones= {"S�", "No"};
	
	/*Componentes del cuadro de di�logo*/
	private JLabel Nombre, Precio, Descuento, volumen, alcohol;
	private JTextField  nombre_bebida, precio_bebida, descuento_bebida, volumen_bebida;
	private JComboBox<String> alcoholBox;
	
	/*Booleano que verifica que se ha pulsado 'OK'*/
	private boolean datosBien=false;

	  /**
	   * Constructor del JDialog. Presenta al usuario los campos necesarios para registrar una nueva bebida.
	   * @param progenitora PANTALLA8 que invoca al cuadro de di�logo
	   */
	  public NuevaBebidaInfo (PANTALLA8 progenitora){
		  
			  /*Instancia las etiquetas y los JTextFields*/
			  Nombre= new JLabel ("Nom:");
			  Precio= new JLabel ("Preu:");
			  Descuento= new JLabel ("Descompte:");
			  volumen= new JLabel ("Volum:");
			  alcohol= new JLabel ("Alcohol?");
			  
			  nombre_bebida= new JTextField ();
			  precio_bebida= new JTextField ();
			  descuento_bebida= new JTextField ();
			  volumen_bebida= new JTextField();
			  alcoholBox=new JComboBox<> (opciones);
			  
			  /*Estructura el cuadro*/
			  JPanel new_panel=  new JPanel();
			  new_panel.setLayout(new GridLayout(5,2));
			  new_panel.add(Nombre);
			  new_panel.add(nombre_bebida);
			  new_panel.add(Precio);
			  new_panel.add(precio_bebida);
			  new_panel.add(Descuento);
			  new_panel.add(descuento_bebida);	  
			  new_panel.add(volumen);
			  new_panel.add(volumen_bebida);
			  new_panel.add(alcohol);
			  new_panel.add(alcoholBox);
			
			/*Establece los botones de aceptar y cancelar*/
		    JButton Aceptar = new JButton("Aceptar");
		    JButton Cancelar = new JButton("Cancel�lar");
		    
		    /*Coloca los botones*/
		    JPanel botones = new JPanel(new FlowLayout());
		    botones.add(Aceptar);
		    botones.add(Cancelar);

		    Container c = getContentPane();
		    c.add(new_panel, BorderLayout.NORTH);
		    c.add(botones, BorderLayout.SOUTH);
		    
		    /*A�ade los listener para determinar que se ha pulsado 'OK'*/
		   Aceptar.addActionListener( new ActionListener() {
		           public void actionPerformed(ActionEvent e) {
		               datosBien = true;
		               setVisible(false);
		           }
		        });
		    Cancelar.addActionListener( new ActionListener() {
		           public void actionPerformed(ActionEvent e) {
		               datosBien = false;
		               setVisible(false);
		           }
		        });

		    pack();
		    setModal(true);
		    setVisible(true);
	  }
	  
	  /**
	   * M�todo para saber si se ha pulsado 'OK'.
	   * @return booleano datosBien true: se ha pulsado OK / false: no se ha pulsado
	   */
	  public boolean datosBien (){
		  return datosBien;
	  }
	  
	  /**
	   * M�todo para obtener el nombre de la bebida.
	   * @return String con contenido del JTextField nombre_bebida
	   */
	  public String getNombre(){
		  return nombre_bebida.getText();
	  }
	  
	  /**
	   * M�todo para obtener el precio de la bebida.
	   * @return String con el contenido del campo precio_bebida
	   */
	  public String getPrecio(){
		  return precio_bebida.getText();
	  }
	  
	  /**
	   * M�todo para obtener el posible descuento de la bebida.
	   * @return String con contenido del campo descuento_bebida
	   */
	  public String getDescuento (){
		  return descuento_bebida.getText();
	  }
	  
	  /**
	   * M�todo para obtener el volumen de la bebida.
	   * @return String con contenido del campo volumen (mL)
	   */
	  public String getVolumen(){
		  return volumen.getText();
	  }
	  
	 /**
	  * M�todo para saber si la bebida tiene alcohol.
	  * @return String "S�" o "No"
	  */
	  public String getAlcohol(){
		  Object seleccion= alcoholBox.getSelectedItem();
		  return seleccion.toString();
	  }

}
