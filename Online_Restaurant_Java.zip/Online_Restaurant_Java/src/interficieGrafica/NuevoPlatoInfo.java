package interficieGrafica;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

/**
 * Clase JDialog para obtener los datos de un nuevo Plato por parte del usuario.
 * Se llama desde una PANTALLA8.
 * @author German Eizaguirre
 *
 */
public class NuevoPlatoInfo extends JDialog{

	private static final long serialVersionUID = 1L;	
	
	/*Opciones de las JComboBox*/
	private String[] opciones= {"S�", "No"};
	
	/*Declaraci�n de las variables que componen el cuadro de di�logo*/
	private JLabel Nombre, Precio, Descuento, celiaco, lactosa, nueces;
	private JTextField nombre_plato, precio_plato, descuento_plato;
	private JComboBox<String> celiacoBox, lactosaBox, nuecesBox;
	
	/*Booleano para determinar que se ha pulsado 'OK'*/
	private boolean datosBien=false;
	  
	/**
	 * Constructor del cuadro de di�logo.
	 * @param progenitora PANTALLA8 que instancia el JDialog.
	 */
	  public NuevoPlatoInfo (PANTALLA8 progenitora){
			  
		  /*Instancia los componentes del JDialog*/
			  Nombre= new JLabel ("Nom:");
			  Precio= new JLabel ("Preu:");
			  Descuento= new JLabel ("Descompte:");
			  celiaco= new JLabel ("Gluten?");
			  lactosa= new JLabel ("Lactosa?");
			  nueces= new JLabel ("Nous?");
			  nombre_plato= new JTextField ();
			  precio_plato= new JTextField ();
			  descuento_plato= new JTextField ();
			  /*JComboBoxes para determianr restricciones*/
			  celiacoBox=new JComboBox<> (opciones);
			  lactosaBox=new JComboBox<> (opciones);
			  nuecesBox=new JComboBox<> (opciones);
			
			/*Estructuramos la ventana*/
			JPanel new_panel=  new JPanel();
			new_panel.setLayout(new GridLayout(6,2));
			new_panel.add(Nombre);
			new_panel.add(nombre_plato);
			new_panel.add(Precio);
			new_panel.add(precio_plato);
			new_panel.add(Descuento);
			new_panel.add(descuento_plato);
			new_panel.add(celiaco);
			new_panel.add(celiacoBox);
			new_panel.add(lactosa);
			new_panel.add(lactosaBox);
			new_panel.add(nueces);
			new_panel.add(nuecesBox);
			
			/*Botones de aceptar y cancelar*/
		    JButton Aceptar = new JButton("Aceptar");
		    JButton Cancelar = new JButton("Cancel�lar");
		    
		    JPanel botones = new JPanel(new FlowLayout());
		    botones.add(Aceptar);
		    botones.add(Cancelar);
		    
		    Container c = getContentPane();
		    c.add(new_panel, BorderLayout.NORTH);
		    c.add(botones, BorderLayout.SOUTH);
		    
		    /*Establece los Listeners para determinar el click del 'OK'*/
		   Aceptar.addActionListener( new ActionListener() {
		           public void actionPerformed(ActionEvent e) {
		               datosBien = true;
		               setVisible(false);
		           }
		        });
		    Cancelar.addActionListener( new ActionListener() {
		           public void actionPerformed(ActionEvent e) {
		               datosBien = false;
		               setVisible(false);
		           }
		        });

		    pack();
		    setModal(true);
		    setVisible(true);
	  }
	  
	  /**
	   * M�todo para saber si se ha pulsado 'OK'.
	   * @return booleano datosBien true: se ha pulsado OK / false: no se ha pulsado
	   */
	  public boolean datosBien (){
		  return datosBien;
	  }
	  
	  /**
	   * M�todo para obtener el nombre del PLato.
	   * @return String con contenido del JTextField nombre_plato
	   */
	  public String getNombre(){
		  return nombre_plato.getText();
	  }
	  
	  /**
	   * M�todo para obtener el precio del Plato.
	   * @return String con el contenido del campo precio_plato
	   */
	  public String getPrecio(){
		  return precio_plato.getText();
	  }
	  
	  /**
	   * M�todo para obtener el posible descuento de la bebida.
	   * @return String con contenido del campo descuento_plato
	   */
	  public String getDescuento (){
		  return descuento_plato.getText();
	  }
	  
	 /**
	  * M�todo para saber si la el plato tiene gluten.
	  * @return String "S�" o "No"
	  */
	  public String getCeliaco(){
		  Object seleccion= celiacoBox.getSelectedItem();
		  return seleccion.toString();
	  }
	  
	 /**
	  * M�todo para saber si el plato tiene lactosa.
	  * @return String "S�" o "No"
	  */
	  public String getLactosa(){
		  Object seleccion= lactosaBox.getSelectedItem();
		  return seleccion.toString();
	  }
  
	 /**
	  * M�todo para saber si el plato tiene nueces.
	  * @return String "S�" o "No"
	  */
	  public String getNueces(){
		  Object seleccion= nuecesBox.getSelectedItem();
		  return seleccion.toString();
	  }
}
